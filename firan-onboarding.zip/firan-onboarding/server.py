#!/usr/bin/env python3
"""
Firan onboarding server.

Python 3.9+, standard library only. Run:
    python3 server.py        (Windows: py server.py)
Then open http://localhost:8000 (onboarding) and http://localhost:8000/admin (dashboard).

Everything else (AI provider and keys, privacy mode, budget, access rules, Telegram, dashboard accounts)
is configured in the dashboard. Optional environment variables:

    FIRAN_PORT, FIRAN_HOST        where to listen (default 127.0.0.1:8000)
    FIRAN_ADMIN_TOKEN             owner token for the dashboard (generated at startup if not set)
    FIRAN_DB                      SQLite path (default data/onboarding.db)
    OPENROUTER_API_KEY, ANTHROPIC_API_KEY, FIRAN_OPENROUTER_MODEL, FIRAN_MODEL   AI defaults
"""

import json
import mimetypes
import sys
import traceback
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse

import admin_api
import employee_api  # noqa: F401  (registers routes)
import notify
from core import (ADMIN_TOKEN, CONTENT, DB_PATH, HOST, MAX_BODY, PORT, ROLE_RANK, ROUTES, STATIC, ApiError, connect,
                  backfill_reviews, init_db, load_settings, migrate_content_file, now)
from llm import PROVIDER_LABEL, resolve_llm


class Handler(BaseHTTPRequestHandler):
    server_version = "FiranOnboarding/3.0"

    def log_message(self, fmt, *args):
        sys.stderr.write(f"{datetime.now():%H:%M:%S} {self.command} {self.path.split('?')[0]} {args[1] if len(args) > 1 else ''}\n")

    def send_json(self, status, payload):
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(body)

    def read_json(self):
        length = int(self.headers.get("Content-Length") or 0)
        if length > MAX_BODY:
            raise ApiError(413, "Request too large.")
        if not length:
            return {}
        try:
            data = json.loads(self.rfile.read(length).decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            raise ApiError(400, "Invalid JSON.")
        if not isinstance(data, dict):
            raise ApiError(400, "Expected a JSON object.")
        return data

    def employee(self, conn):
        auth = self.headers.get("Authorization", "")
        token = auth[7:].strip() if auth.startswith("Bearer ") else ""
        if not token:
            raise ApiError(401, "Please sign in.")
        row = conn.execute("SELECT u.* FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token = ?", (token,)).fetchone()
        if not row:
            raise ApiError(401, "Your session has expired. Please sign in again.")
        conn.execute("UPDATE users SET last_seen = ? WHERE id = ?", (now(), row["id"]))
        return row, token

    def admin(self, conn, min_role):
        token = self.headers.get("X-Admin-Token", "").strip()
        actor = admin_api.resolve_admin(conn, token)
        if not actor:
            raise ApiError(403, "Sign in to the dashboard.")
        if ROLE_RANK[actor["role"]] < ROLE_RANK[min_role]:
            raise ApiError(403, f"Your role ({actor['role']}) cannot do this.")
        return actor, token

    def dispatch(self, method):
        path = urlparse(self.path).path
        if path.startswith("/api/"):
            for m, rx, auth, role, fn in ROUTES:
                match = rx.match(path)
                if m == method and match:
                    return self.run_api(fn, auth, role, match.groups())
            return self.send_json(404, {"error": "Unknown API endpoint."})
        if method == "GET":
            return self.serve_static(path)
        self.send_json(405, {"error": "Method not supported."})

    def run_api(self, fn, auth, role, params):
        try:
            body = self.read_json() if self.command in ("POST", "PUT", "DELETE") else {}
            conn = connect()
            try:
                with conn:
                    actor = token = None
                    if auth == "user":
                        actor, token = self.employee(conn)
                    elif auth == "admin":
                        actor, token = self.admin(conn, role)
                    result = fn(self, conn, actor, body, *params, token=token)
            finally:
                conn.close()
            status, payload = result if isinstance(result, tuple) else (200, result)
            self.send_json(status, payload)
        except ApiError as e:
            self.send_json(e.status, {"error": e.message})
        except Exception:  # noqa: BLE001
            traceback.print_exc()
            self.send_json(500, {"error": "Internal server error."})

    def serve_static(self, path):
        if path in ("/", "/index.html"):
            target = STATIC / "index.html"
        elif path in ("/admin", "/admin/"):
            target = STATIC / "admin.html"
        else:
            target = (STATIC / path.lstrip("/")).resolve()
            if STATIC.resolve() not in target.parents:
                return self.send_json(404, {"error": "Not found."})
        if not target.is_file():
            self.send_response(404)
            self.send_header("Content-Length", "0")
            self.end_headers()
            return
        data = target.read_bytes()
        ctype = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
        if ctype.startswith("text/") or ctype.endswith("javascript"):
            ctype += "; charset=utf-8"
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-cache")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        self.dispatch("GET")

    def do_POST(self):
        self.dispatch("POST")

    def do_DELETE(self):
        self.dispatch("DELETE")


def main():
    if not (STATIC / "index.html").is_file():
        sys.exit("static/index.html not found next to server.py")
    init_db()
    migrate_content_file()
    CONTENT.get()
    backfill_reviews()
    conn = connect()
    try:
        provider, _, model = resolve_llm(load_settings(conn))
    finally:
        conn.close()
    assistant = f"{PROVIDER_LABEL[provider]} ({model})" if provider != "kb" else "knowledge base only (add an AI key in the dashboard)"
    notify.start_watcher()
    httpd = ThreadingHTTPServer((HOST, PORT), Handler)
    shown = "localhost" if HOST in ("127.0.0.1", "0.0.0.0") else HOST
    print(f"""
  Firan onboarding
  ────────────────────────────────────────
  Onboarding       http://{shown}:{PORT}
  Dashboard        http://{shown}:{PORT}/admin
  Owner token      {ADMIN_TOKEN}
  Assistant        {assistant}
  Database         {DB_PATH}

  Stop: Ctrl+C
""", flush=True)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nServer stopped.")


if __name__ == "__main__":
    main()
