"""Shared core: configuration, content, database, settings and routing primitives."""

import copy
import hashlib
import html
import json
import os
import re
import secrets
import sqlite3
import threading
from datetime import datetime, timedelta, timezone
from pathlib import Path

BASE = Path(__file__).resolve().parent
STATIC = BASE / "static"
CONTENT_PATH = BASE / "content.json"
DB_PATH = Path(os.environ.get("FIRAN_DB", BASE / "data" / "onboarding.db"))
HISTORY_DIR = DB_PATH.parent / "content-history"
HISTORY_KEEP = 30

HOST = os.environ.get("FIRAN_HOST", "127.0.0.1")
PORT = int(os.environ.get("FIRAN_PORT", "8000"))
ADMIN_TOKEN = os.environ.get("FIRAN_ADMIN_TOKEN") or secrets.token_urlsafe(12)

PASS_SCORE = 80
MAX_BODY = 256 * 1024
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
ROLE_RANK = {"mentor": 1, "editor": 2, "owner": 3}
REVIEW_INTERVALS_DAYS = [1, 3, 7, 30, 90]      # Leitner boxes 0..4; box 5 = mastered


def utcnow():
    return datetime.now(timezone.utc)


def now():
    return utcnow().isoformat(timespec="seconds")


def parse_ts(s):
    try:
        return datetime.fromisoformat(s)
    except (TypeError, ValueError):
        return None


# ─────────────────────────────────────────────
# Errors, routing, validation helpers
# ─────────────────────────────────────────────
class ApiError(Exception):
    def __init__(self, status, message):
        super().__init__(message)
        self.status = status
        self.message = message


ROUTES = []


def route(method, pattern, auth="user", role="mentor"):
    """auth: None (public), 'user' (employee session) or 'admin' (dashboard, minimum role)."""
    rx = re.compile("^" + pattern + "$")

    def deco(fn):
        ROUTES.append((method, rx, auth, role, fn))
        return fn

    return deco


def text(v, where, field, required=True, max_len=20000):
    if v is None:
        v = ""
    if not isinstance(v, str):
        raise ApiError(400, f"{where}: {field} must be text.")
    v = v.strip()
    if required and not v:
        raise ApiError(400, f"{where}: {field} is empty.")
    if len(v) > max_len:
        raise ApiError(400, f"{where}: {field} is too long (max {max_len} characters).")
    return v


def strip_html(s):
    s = re.sub(r"</t[dh]>", " | ", s or "")
    s = re.sub(r"</(tr|p|li|h\d|div)>", "\n", s)
    s = re.sub(r"<[^>]+>", " ", s)
    s = html.unescape(s)
    s = re.sub(r"[ \t]+", " ", s)
    s = re.sub(r"\n\s*\n+", "\n", s)
    return s.strip()


def slugify(s, taken=()):
    base = re.sub(r"[^a-z0-9]+", "-", (s or "").lower()).strip("-")[:32] or "stage"
    slug, n = base, 2
    while slug in taken:
        slug, n = f"{base}-{n}", n + 1
    return slug


def new_id(prefix):
    return f"{prefix}{secrets.token_hex(3)}"


# ─────────────────────────────────────────────
# Content
# ─────────────────────────────────────────────
def ensure_ids(data):
    """Adds stable keys to stages, ids to questions and milestones. Returns True if anything changed.
    Existing stages get keys s1, s2, … so they line up with progress migrated from stage positions."""
    changed = False
    data.setdefault("tracks", [])
    data.setdefault("milestones", [])
    data.setdefault("assistantNotes", [])
    data.setdefault("glossary", [])
    taken = {st.get("key") for st in data["stages"] if st.get("key")}
    for i, st in enumerate(data["stages"]):
        if not st.get("key"):
            key = f"s{i + 1}"
            st["key"] = key if key not in taken else slugify(st.get("title"), taken)
            taken.add(st["key"])
            changed = True
        if "tracks" not in st:
            st["tracks"] = []
            changed = True
        for sec in st.get("sections", []):
            if sec.get("type") == "test":
                for q in sec.get("questions", []):
                    if not q.get("id"):
                        q["id"] = new_id("q")
                        changed = True
    for m in data["milestones"]:
        if not m.get("id"):
            m["id"] = new_id("m")
            changed = True
    for g in data["glossary"]:
        if not g.get("id"):
            g["id"] = new_id("g")
            changed = True
    return changed


class Content:
    """content.json is reloaded automatically when the file changes."""

    def __init__(self, path):
        self.path = path
        self._mtime = None
        self._data = None
        self._knowledge = None
        self._lock = threading.Lock()

    def get(self):
        mtime = self.path.stat().st_mtime
        with self._lock:
            if mtime != self._mtime:
                self._data = json.loads(self.path.read_text(encoding="utf-8"))
                ensure_ids(self._data)
                self._mtime = mtime
                self._knowledge = None
            return self._data

    def invalidate(self):
        with self._lock:
            self._mtime = None

    @property
    def stages(self):
        return self.get()["stages"]

    @property
    def tracks(self):
        return self.get().get("tracks", [])

    def stage(self, key):
        for st in self.stages:
            if st["key"] == key:
                return st
        return None

    def visible(self, track):
        """Stages this track sees, in order. A stage with no tracks is for everyone."""
        return [st for st in self.stages if not st.get("tracks") or (track and track in st["tracks"])]

    def test_questions(self, key):
        st = self.stage(key)
        for sec in (st or {}).get("sections", []):
            if sec.get("type") == "test":
                return sec["questions"]
        return []

    def question_index(self):
        """qid -> (stage, question)."""
        out = {}
        for st in self.stages:
            for q in self.test_questions(st["key"]):
                out[q["id"]] = (st, q)
        return out

    def public(self):
        data = copy.deepcopy(self.get())
        for stage in data["stages"]:
            for section in stage["sections"]:
                if section.get("type") == "test":
                    for q in section["questions"]:
                        q.pop("correct", None)
        data.pop("assistantNotes", None)
        data["passScore"] = PASS_SCORE
        return data

    def stage_material(self, key):
        st = self.stage(key)
        parts = [f"Stage: {st['title']}. {st['description']}"]
        for sec in st["sections"]:
            body = sec.get("content") or sec.get("html") or sec.get("intro") or ""
            if not body:
                continue
            src = sec.get("src")
            label = f" [§ {src}]" if src and src[0].isdigit() else ""
            parts.append(f"### {sec.get('heading', 'Note')}{label}\n{strip_html(body)}")
        return "\n\n".join(parts)

    def knowledge(self):
        self.get()
        if self._knowledge:
            return self._knowledge
        parts = []
        for n, st in enumerate(self.stages, 1):
            parts.append(f"\n## Stage {n}. {st['title']}: {st['description']}")
            for sec in st["sections"]:
                if sec.get("type") in ("test", "mentor", "layers", "flow", "er", "gantt"):
                    continue
                src = sec.get("src")
                label = f" [§ {src}]" if src and src[0].isdigit() else (f" [{src}]" if src else "")
                body = sec.get("content") or sec.get("html") or sec.get("intro") or ""
                parts.append(f"### {sec.get('heading', '')}{label}\n{strip_html(body)}")
        gl = self.get().get("glossary", [])
        if gl:
            parts.append("\n## Glossary")
            parts.extend(f"- {g['term']}: {g['definition']}" for g in gl)
        ms = self.get().get("milestones", [])
        if ms:
            parts.append("\n## First-month plan")
            parts.extend(f"- {m['when']}: {m['title']}" for m in ms)
        notes = self.get().get("assistantNotes", [])
        if notes:
            parts.append("\n## Additional notes")
            parts.extend(notes)
        self._knowledge = "\n".join(parts)
        return self._knowledge


CONTENT = Content(CONTENT_PATH)


def write_content(data):
    """Atomic write with a backup of the previous version."""
    HISTORY_DIR.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    backup = HISTORY_DIR / f"content-{stamp}.json"
    n = 1
    while backup.exists():
        backup = HISTORY_DIR / f"content-{stamp}-{n}.json"
        n += 1
    if CONTENT_PATH.exists():
        backup.write_bytes(CONTENT_PATH.read_bytes())
    tmp = CONTENT_PATH.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, CONTENT_PATH)
    CONTENT.invalidate()
    for old in sorted(HISTORY_DIR.glob("content-*.json"))[:-HISTORY_KEEP]:
        old.unlink(missing_ok=True)


def migrate_content_file():
    data = json.loads(CONTENT_PATH.read_text(encoding="utf-8"))
    if ensure_ids(data):
        write_content(data)


# ─────────────────────────────────────────────
# Database
# ─────────────────────────────────────────────
SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT NOT NULL UNIQUE,
    created_at TEXT NOT NULL, last_seen TEXT, track TEXT, buddy TEXT, start_date TEXT
);
CREATE TABLE IF NOT EXISTS sessions (
    token TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS progress (
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, stage_key TEXT NOT NULL,
    test_passed INTEGER NOT NULL DEFAULT 0, test_score INTEGER,
    mentor_requested_at TEXT, mentor_confirmed_at TEXT, completed_at TEXT,
    PRIMARY KEY (user_id, stage_key)
);
CREATE TABLE IF NOT EXISTS test_attempts (
    id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    stage_key TEXT, answers TEXT NOT NULL, score INTEGER NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS dossier_verdicts (
    user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE, verdict TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS chat_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    role TEXT NOT NULL CHECK (role IN ('user', 'assistant')), text TEXT NOT NULL, src TEXT, created_at TEXT NOT NULL,
    question TEXT, unanswered INTEGER NOT NULL DEFAULT 0, rating INTEGER, resolved INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL, updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS llm_calls (
    id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT NOT NULL, purpose TEXT NOT NULL, provider TEXT, model TEXT,
    prompt_tokens INTEGER, completion_tokens INTEGER, cost REAL, user_id INTEGER, ok INTEGER NOT NULL, error TEXT
);
CREATE TABLE IF NOT EXISTS prompt_versions (
    id INTEGER PRIMARY KEY AUTOINCREMENT, prompt TEXT NOT NULL, created_at TEXT NOT NULL, author TEXT
);
CREATE TABLE IF NOT EXISTS checks (
    id INTEGER PRIMARY KEY AUTOINCREMENT, question TEXT NOT NULL, expected TEXT NOT NULL, created_at TEXT NOT NULL,
    last_pass INTEGER, last_reason TEXT, last_answer TEXT, last_run_at TEXT
);
CREATE TABLE IF NOT EXISTS reviews (
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, qid TEXT NOT NULL, stage_key TEXT NOT NULL,
    box INTEGER NOT NULL DEFAULT 0, due_at TEXT, last_at TEXT, PRIMARY KEY (user_id, qid)
);
CREATE TABLE IF NOT EXISTS review_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    qid TEXT NOT NULL, stage_key TEXT NOT NULL, correct INTEGER NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS user_milestones (
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, milestone_id TEXT NOT NULL, done_at TEXT NOT NULL,
    PRIMARY KEY (user_id, milestone_id)
);
CREATE TABLE IF NOT EXISTS invites (
    token TEXT PRIMARY KEY, name TEXT, email TEXT, track TEXT, buddy TEXT, start_date TEXT,
    created_at TEXT NOT NULL, created_by TEXT, used_at TEXT, used_by INTEGER
);
CREATE TABLE IF NOT EXISTS admins (
    id INTEGER PRIMARY KEY AUTOINCREMENT, email TEXT NOT NULL UNIQUE, name TEXT NOT NULL, role TEXT NOT NULL,
    pw_hash TEXT NOT NULL, created_at TEXT NOT NULL, last_login TEXT
);
CREATE TABLE IF NOT EXISTS admin_sessions (
    token TEXT PRIMARY KEY, admin_id INTEGER NOT NULL REFERENCES admins(id) ON DELETE CASCADE, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS audit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT NOT NULL, actor TEXT NOT NULL, action TEXT NOT NULL, detail TEXT
);
CREATE TABLE IF NOT EXISTS notified (kind TEXT NOT NULL, ref TEXT NOT NULL, created_at TEXT NOT NULL, PRIMARY KEY (kind, ref));
CREATE INDEX IF NOT EXISTS idx_chat_user ON chat_messages(user_id, id);
CREATE INDEX IF NOT EXISTS idx_attempts_user ON test_attempts(user_id, stage_key);
CREATE INDEX IF NOT EXISTS idx_llm_day ON llm_calls(created_at);
CREATE INDEX IF NOT EXISTS idx_reviews_due ON reviews(user_id, due_at);
"""


def connect():
    conn = sqlite3.connect(DB_PATH, timeout=15)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def _columns(conn, table):
    return {r[1] for r in conn.execute(f"PRAGMA table_info({table})")}


def _migrate(conn):
    """Upgrades a database created by an earlier version in place."""
    tables = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    if "users" in tables:
        cols = _columns(conn, "users")
        for col in ("track", "buddy", "start_date"):
            if col not in cols:
                conn.execute(f"ALTER TABLE users ADD COLUMN {col} TEXT")
    if "progress" in tables and "stage_index" in _columns(conn, "progress"):
        conn.executescript("""
            CREATE TABLE progress_v3 (
                user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, stage_key TEXT NOT NULL,
                test_passed INTEGER NOT NULL DEFAULT 0, test_score INTEGER,
                mentor_requested_at TEXT, mentor_confirmed_at TEXT, completed_at TEXT,
                PRIMARY KEY (user_id, stage_key));
            INSERT INTO progress_v3 SELECT user_id, 's' || (stage_index + 1), test_passed, test_score,
                mentor_requested_at, mentor_confirmed_at, completed_at FROM progress;
            DROP TABLE progress;
            ALTER TABLE progress_v3 RENAME TO progress;
        """)
    if "test_attempts" in tables and "stage_index" in _columns(conn, "test_attempts"):
        conn.executescript("""
            CREATE TABLE test_attempts_v3 (
                id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                stage_key TEXT, answers TEXT NOT NULL, score INTEGER NOT NULL, created_at TEXT NOT NULL);
            INSERT INTO test_attempts_v3 (id, user_id, stage_key, answers, score, created_at)
                SELECT id, user_id, 's' || (stage_index + 1), answers, score, created_at FROM test_attempts;
            DROP TABLE test_attempts;
            ALTER TABLE test_attempts_v3 RENAME TO test_attempts;
        """)
    if "chat_messages" in tables:
        cols = _columns(conn, "chat_messages")
        for col, ddl in (("question", "TEXT"), ("unanswered", "INTEGER NOT NULL DEFAULT 0"),
                         ("rating", "INTEGER"), ("resolved", "INTEGER NOT NULL DEFAULT 0")):
            if col not in cols:
                conn.execute(f"ALTER TABLE chat_messages ADD COLUMN {col} {ddl}")


def init_db():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = connect()
    try:
        conn.execute("PRAGMA journal_mode = WAL")
        conn.execute("PRAGMA foreign_keys = OFF")
        _migrate(conn)
        conn.executescript(SCHEMA)
        conn.commit()
    finally:
        conn.close()


# ─────────────────────────────────────────────
# Settings (edited in the dashboard)
# ─────────────────────────────────────────────
SETTING_DEFAULTS = {
    "provider": "auto",
    "openrouter_model": os.environ.get("FIRAN_OPENROUTER_MODEL", "anthropic/claude-haiku-4.5"),
    "openrouter_fallback": "",
    "anthropic_model": os.environ.get("FIRAN_MODEL", "claude-haiku-4-5-20251001"),
    "openrouter_key": "",
    "anthropic_key": "",
    "system_prompt": "",                 # empty = built-in default (see llm.DEFAULT_SYSTEM_PROMPT)
    "privacy_mode": "1",                 # OpenRouter: zero data retention + no data collection
    "daily_budget_usd": "",              # empty = no limit
    "invite_only": "0",
    "allowed_domains": "",               # comma-separated, empty = any
    "telegram_token": "",
    "telegram_chat_id": "",
    "notify_stuck_days": "3",
}


def load_settings(conn):
    s = dict(SETTING_DEFAULTS)
    for r in conn.execute("SELECT key, value FROM settings"):
        if r["key"] in s:
            s[r["key"]] = r["value"]
    return s


def save_settings(conn, updates):
    ts = now()
    for k, v in updates.items():
        conn.execute(
            "INSERT INTO settings (key, value, updated_at) VALUES (?, ?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at",
            (k, str(v), ts),
        )


def flag(s, key):
    return str(s.get(key, "")).strip() in ("1", "true", "True")


def num(s, key):
    try:
        return float(str(s.get(key, "")).strip())
    except ValueError:
        return None


def audit(conn, actor, action, detail=""):
    name = actor.get("name") if isinstance(actor, dict) else str(actor)
    conn.execute("INSERT INTO audit_log (created_at, actor, action, detail) VALUES (?, ?, ?, ?)",
                 (now(), name or "unknown", action, detail[:1000]))


# ─────────────────────────────────────────────
# Passwords (dashboard accounts)
# ─────────────────────────────────────────────
def hash_password(pw):
    salt = secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac("sha256", pw.encode(), bytes.fromhex(salt), 200_000).hex()
    return f"pbkdf2${salt}${digest}"


def check_password(pw, stored):
    try:
        _, salt, digest = stored.split("$")
    except ValueError:
        return False
    test = hashlib.pbkdf2_hmac("sha256", pw.encode(), bytes.fromhex(salt), 200_000).hex()
    return secrets.compare_digest(test, digest)


# ─────────────────────────────────────────────
# Progress helpers shared by employee and admin APIs
# ─────────────────────────────────────────────
def load_progress(conn, uid):
    stages = {}
    for r in conn.execute("SELECT * FROM progress WHERE user_id = ?", (uid,)):
        mentor = "confirmed" if r["mentor_confirmed_at"] else ("requested" if r["mentor_requested_at"] else None)
        stages[r["stage_key"]] = {
            "completed": bool(r["completed_at"]), "completedAt": r["completed_at"],
            "testPassed": bool(r["test_passed"]), "testScore": r["test_score"],
            "mentor": mentor, "verified": mentor == "confirmed",
        }
    v = conn.execute("SELECT verdict FROM dossier_verdicts WHERE user_id = ?", (uid,)).fetchone()
    return {"stages": stages, "dossierVerdict": v["verdict"] if v else None}


def completed_keys(conn, uid):
    return {r["stage_key"] for r in conn.execute(
        "SELECT stage_key FROM progress WHERE user_id = ? AND completed_at IS NOT NULL", (uid,))}


def next_stage(conn, user):
    """First visible stage the user has not completed, or None when done."""
    done = completed_keys(conn, user["id"])
    for st in CONTENT.visible(user["track"]):
        if st["key"] not in done:
            return st
    return None


def backfill_reviews():
    """Schedules spaced review for quizzes passed before reviews existed (or after questions were added)."""
    conn = connect()
    try:
        due = schedule_after(0)
        for r in conn.execute("SELECT user_id, stage_key FROM progress WHERE test_passed = 1").fetchall():
            for q in CONTENT.test_questions(r["stage_key"]):
                conn.execute("INSERT OR IGNORE INTO reviews (user_id, qid, stage_key, box, due_at) VALUES (?, ?, ?, 0, ?)",
                             (r["user_id"], q["id"], r["stage_key"], due))
        conn.commit()
    finally:
        conn.close()


def schedule_after(box):
    if box >= len(REVIEW_INTERVALS_DAYS):
        return None
    return (utcnow() + timedelta(days=REVIEW_INTERVALS_DAYS[box])).isoformat(timespec="seconds")
