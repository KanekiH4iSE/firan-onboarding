"""AI providers (OpenRouter, Anthropic API), usage accounting and the built-in knowledge base."""

import json
import os
import re
import sys
import urllib.error
import urllib.request
from datetime import datetime, timezone

from core import CONTENT, connect, flag, now, num

ENV_ANTHROPIC_KEY = os.environ.get("ANTHROPIC_API_KEY", "").strip()
ENV_OPENROUTER_KEY = os.environ.get("OPENROUTER_API_KEY", "").strip()
OPENROUTER_URL = os.environ.get("FIRAN_OPENROUTER_URL", "https://openrouter.ai/api/v1/chat/completions")
ANTHROPIC_URL = "https://api.anthropic.com/v1/messages"
PROVIDERS = ("auto", "openrouter", "anthropic", "kb")
PROVIDER_LABEL = {"openrouter": "OpenRouter", "anthropic": "Anthropic API"}

DEFAULT_SYSTEM_PROMPT = """You are the onboarding assistant at Firan. A new team member is asking about the company, the Firan Ontology platform, the Arvand Bank pilot and how we work.

Rules:
- Answer in English, briefly: 2–4 sentences, no lists or headings.
- Rely only on the onboarding materials. Do not invent figures, timelines, clients, names or statuses that are not in them.
- If the materials do not contain the answer, say so and suggest asking their mentor.
- If they ask for the answer to a quiz question, do not name the option; explain the topic and point to the section.
- If the answer relies on a specific section, end with the section tag in the form "§ 1.2"."""

# Fixed rule appended after the editable prompt: lets the dashboard find questions the materials do not cover.
GAP_RULE = ("\n\nSystem rule (always applies): if the onboarding materials do not contain the answer, "
            "start your reply with the exact token [NO_ANSWER] and then answer as instructed above.")
NO_ANSWER_RE = re.compile(r"^\s*\[NO_ANSWER\]\s*", re.I)
SRC_TAIL = re.compile(r"\s*[\(\[]?§\s*([0-9][0-9.,\s]*[0-9])[\)\]]?\.?\s*$")


class LLMError(Exception):
    pass


def system_prompt_of(s):
    return s["system_prompt"].strip() or DEFAULT_SYSTEM_PROMPT


def build_system_prompt(template, knowledge):
    if "{knowledge}" in template:
        body = template.replace("{knowledge}", knowledge)
    else:
        body = template.rstrip() + "\n\nOnboarding materials:\n" + knowledge
    return body + GAP_RULE


def provider_keys(s):
    return {"openrouter": s["openrouter_key"] or ENV_OPENROUTER_KEY,
            "anthropic": s["anthropic_key"] or ENV_ANTHROPIC_KEY}


def resolve_llm(s):
    """(provider, key, model); provider 'kb' means no AI is available."""
    keys = provider_keys(s)
    p = s["provider"]
    if p == "auto":
        p = "openrouter" if keys["openrouter"] else ("anthropic" if keys["anthropic"] else "kb")
    if p == "openrouter" and keys["openrouter"]:
        return "openrouter", keys["openrouter"], s["openrouter_model"]
    if p == "anthropic" and keys["anthropic"]:
        return "anthropic", keys["anthropic"], s["anthropic_model"]
    return "kb", None, None


def spend_today():
    day = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    conn = connect()
    try:
        r = conn.execute("SELECT COALESCE(SUM(cost), 0) FROM llm_calls WHERE substr(created_at, 1, 10) = ?", (day,)).fetchone()
        return float(r[0] or 0)
    finally:
        conn.close()


def _log_call(purpose, provider, model, usage, cost, user_id, ok, error=None):
    conn = connect()
    try:
        conn.execute(
            "INSERT INTO llm_calls (created_at, purpose, provider, model, prompt_tokens, completion_tokens, cost, user_id, ok, error) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (now(), purpose, provider, model, usage.get("in"), usage.get("out"), cost, user_id, 1 if ok else 0,
             (error or "")[:500] or None))
        conn.commit()
    finally:
        conn.close()


def llm_complete(s, system, messages, max_tokens=700, purpose="other", user_id=None):
    """Returns (text, provider, model_used). Never call while holding a DB write transaction."""
    provider, key, model = resolve_llm(s)
    if provider == "kb":
        raise LLMError("No AI provider is configured. Add an OpenRouter or Anthropic key in the Assistant tab.")
    budget = num(s, "daily_budget_usd")
    if budget is not None and budget >= 0 and spend_today() >= budget:
        raise LLMError(f"Today's AI budget of ${budget:g} is used up. It resets at midnight UTC.")
    label = PROVIDER_LABEL[provider]

    if provider == "openrouter":
        payload = {"max_tokens": max_tokens, "messages": [{"role": "system", "content": system}] + messages}
        fallback = s.get("openrouter_fallback", "").strip()
        if fallback and fallback != model:
            payload["models"] = [model, fallback]
        else:
            payload["model"] = model
        if flag(s, "privacy_mode"):
            payload["provider"] = {"zdr": True, "data_collection": "deny"}
        url = OPENROUTER_URL
        headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json",
                   "HTTP-Referer": "http://localhost", "X-OpenRouter-Title": "Firan onboarding", "X-Title": "Firan onboarding"}
    else:
        payload = {"model": model, "max_tokens": max_tokens, "system": system, "messages": messages}
        url = ANTHROPIC_URL
        headers = {"x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json"}

    req = urllib.request.Request(url, data=json.dumps(payload).encode("utf-8"), headers=headers, method="POST")
    try:
        try:
            with urllib.request.urlopen(req, timeout=90) as resp:
                data = json.load(resp)
        except urllib.error.HTTPError as e:
            detail = ""
            try:
                body = json.loads(e.read().decode("utf-8", "replace"))
                err = body.get("error")
                detail = err.get("message", "") if isinstance(err, dict) else str(err or "")
            except (ValueError, AttributeError):
                pass
            raise LLMError(f"{label} returned HTTP {e.code}" + (f": {detail}" if detail else "."))
        except (urllib.error.URLError, TimeoutError, OSError) as e:
            raise LLMError(f"Could not reach {label}: {getattr(e, 'reason', e)}")
        except ValueError:
            raise LLMError(f"{label} returned a response that is not JSON.")

        usage = data.get("usage") or {}
        if provider == "openrouter":
            if isinstance(data.get("error"), dict):
                raise LLMError(f"{label}: {data['error'].get('message', 'unknown error')}")
            choices = data.get("choices") or []
            content = (choices[0].get("message") or {}).get("content") if choices else ""
            if isinstance(content, list):
                content = "".join(p.get("text", "") for p in content if isinstance(p, dict))
            text = (content or "").strip()
            used = data.get("model") or model
            tokens = {"in": usage.get("prompt_tokens"), "out": usage.get("completion_tokens")}
            cost = usage.get("cost")
        else:
            text = "".join(b.get("text", "") for b in data.get("content", []) if b.get("type") == "text").strip()
            used = data.get("model") or model
            tokens = {"in": usage.get("input_tokens"), "out": usage.get("output_tokens")}
            cost = None
        if not text:
            raise LLMError(f"{label} returned an empty response.")
    except LLMError as e:
        _log_call(purpose, provider, model, {}, None, user_id, False, str(e))
        raise
    _log_call(purpose, provider, used, tokens, float(cost) if isinstance(cost, (int, float)) else None, user_id, True)
    return text, provider, used


def ask_assistant(s, history, question, template=None, purpose="assistant", user_id=None):
    """Returns (text, src, unanswered, provider, model)."""
    system = build_system_prompt(template or system_prompt_of(s), CONTENT.knowledge())
    text, provider, model = llm_complete(s, system, history + [{"role": "user", "content": question}], 600, purpose, user_id)
    unanswered = bool(NO_ANSWER_RE.match(text))
    text = NO_ANSWER_RE.sub("", text).strip()
    src = None
    m = SRC_TAIL.search(text)
    if m:
        src = m.group(1).strip()
        text = text[: m.start()].rstrip()
    return text, src, unanswered, provider, model


def extract_json(text):
    t = re.sub(r"^```(?:json)?\s*|\s*```$", "", text.strip(), flags=re.I)
    try:
        return json.loads(t)
    except ValueError:
        pass
    starts = [i for i in (t.find("["), t.find("{")) if i != -1]
    if not starts:
        raise LLMError("The model did not return JSON. Try again.")
    end = max(t.rfind("]"), t.rfind("}"))
    try:
        return json.loads(t[min(starts):end + 1])
    except ValueError:
        raise LLMError("The model returned malformed JSON. Try again.")


def log_fallback(e):
    sys.stderr.write(f"  ! {e} (answered from the knowledge base)\n")


# ─────────────────────────────────────────────
# Built-in knowledge base (used when no AI provider is available)
# ─────────────────────────────────────────────
KB = [
    (["mule", "dropper", "cluster"], "1.7", "A money mule scheme is a network of formally unrelated accounts that receive victims’ funds and move them on quickly. From a flag on one account, the platform finds the whole cluster through shared phones, addresses and devices, reconstructs the money trail and surfaces participants who have not been flagged yet."),
    (["entity resolution", "matching", "transliter", "merge", "duplicate"], "2.2", "Entity resolution joins records about the same person across systems despite different transliterations, typos and passport or phone formats. Every match has a confidence level: reliable matches are merged automatically, disputed ones are shown to the analyst as a possible link."),
    (["dossier"], "2.6", "The dossier is the agent’s output: what was checked, what was found, facts linked to records, hypotheses with results, a timeline, a slice of the graph and a recommendation. The recommendation is not a decision: the analyst decides, and their verdict is stored as a label."),
    (["playbook"], "2.5", "A playbook describes how a type of scheme is investigated: which hypotheses to test, with which tools and what confirms them. The pilot prepares four: external, internal and collusive fraud, plus money mules. They are tuned together with the bank’s security team."),
    (["panopticon"], "2.8", "Panopticon scores the risk of every transaction in real time and is already live, with the status “Implemented”. A transaction sent for review is closed at card level, while a blocked one opens a dossier automatically. The card and the dossier are two levels of the same workspace."),
    (["cctv", "video", "camera", "biometric", "face recogn"], "3.10", "During the pilot, CCTV is only a link to a clip by branch and time, which the analyst watches themselves. There is no face recognition or biometric processing; expanding video use requires legal sign-off with the bank."),
    (["arvand", "pilot"], "3.7, 3.8", "We have prepared a platform concept and pilot plan for Arvand Bank: six stages over roughly 16 weeks, from assessment and adapters to shadow mode on live cases. Quality is tested on 50–100 of the bank’s closed cases, which the platform re-investigates without knowing the outcome."),
    (["agent", "investigat", "case", "red flag"], "1.5", "An investigation starts with a red-flag case. The platform picks a playbook, and the agent uses platform tools to traverse the graph around the case, test hypotheses and build a dossier where every finding is backed by a bank record. Deterministic algorithms do the traversal; the language model handles reasoning and write-up."),
    (["audit", "explainab", "regulator"], "3.5", "Every finding in the dossier traces back to a record in a bank system. The audit log stores user actions, the agent’s reasoning, tool calls and the versions of playbooks and matching rules, so a decision can be reconstructed and shown to an auditor or regulator."),
    (["role", "admin", "access", "permission"], "3.4", "Analysts see cases in their own area, managers see the overall picture, and administrators see settings without access to case contents. Personal data is masked for roles that do not need it."),
    (["on-prem", "onprem", "on prem", "perimeter", "cloud", "leave the bank"], "3.1", "Every component, including the agent’s language model, runs in the bank’s infrastructure and never calls external services, so the platform can run in an isolated environment. Adapters read the bank’s systems read-only and data never leaves the perimeter."),
    (["kyc", "kyb", "scoring", "ubo", "beneficial"], "1.4", "KYC / KYB and credit scoring are the next directions on the same data model, with the status “Roadmap”. They reuse the sources already connected: checking customers and beneficial owners with their connections, and assessing borrowers with guarantees and account behaviour."),
    (["effect", "number", "percent", "promise", "roi", "result"], "1.8", "The benefit comes from speed, completeness, evidence and accumulated expertise. Quantitative effects are measured on the bank’s data during the pilot and are not promised in advance."),
    (["status", "implemented", "roadmap"], "p. 2", "“Implemented” means already running in Firan products, primarily Panopticon. “Pilot” means included in the pilot scope. “Roadmap” means the next stages after the pilot."),
    (["linear", "daily", "update", "task"], None, "Linear is the single source of truth for tasks: if a task is not in Linear, it does not exist. Update statuses every day by 11:00 and keep discussions in issue comments."),
    (["ontology", "digital twin", "warehouse", "firan", "who we are", "data model"], "1.2", "Firan Ontology is a digital twin of the bank: customers, staff, accounts, transactions, loans, collateral and documents as single connected objects. It updates continuously from the bank’s systems, keeps a link to every source record and connects those systems rather than replacing them. Integration happens once, and AI systems are rolled out on top."),
]
KB_FALLBACK = "The onboarding materials do not cover this. Ask your mentor or check the Firan Ontology concept."


def kb_answer(question):
    """(text, src, unanswered)"""
    q = question.lower()
    for keys, src, text in KB:
        if any(k in q for k in keys):
            return text, src, False
    return KB_FALLBACK, None, True
