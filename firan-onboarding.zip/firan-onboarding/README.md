# Firan onboarding

Team onboarding built on the Firan Ontology concept: an employee app, a backend and a dashboard.
Python 3.9+ and the standard library only, so there is nothing to install.

## Run it

```bash
python3 server.py        # Windows: py server.py
```

Or double-click `start.command` (macOS) or `start.bat` (Windows).

- Onboarding: http://localhost:8000
- Dashboard: http://localhost:8000/admin — sign in with the **owner token** printed in the terminal, then create personal accounts in **Settings**.

Keep the terminal window open: it is the server. Stop it with `Ctrl+C`.
Upgrading from an earlier version keeps all progress: the database and `content.json` are migrated on the first start.

## For employees

- **Home**: a greeting with the day of onboarding, the stages as a honeycomb (solid = done, thick outline = up next, grey = locked), the next stage, reviews due, the first-month plan and people to ask.
- **Glossary**: the first mention of each term in a stage is underlined with dots and explains itself on hover, focus or tap; a searchable glossary page shows where each term appears.
- Stages with quizzes and mentor sign-offs; quizzes are graded on the server.
- **Tracks**: if the owner defines tracks (e.g. Engineering, Business), each person sees the shared stages plus their track's.
- **Review**: after a quiz is passed, its questions come back after 1, 3, 7, 30 and 90 days; a wrong answer starts that question over.
- **First month**: buddy, mentor, start date and a checklist of milestones.
- **Assistant** with 👍/👎 on every answer.

## Dashboard

Roles: **mentor** (Team, Insights, confirm meetings) < **editor** (+ Content, invites, system prompt, control questions) < **owner** (+ AI keys, budget, access, Telegram, accounts, audit log).

- **Team** — a matrix of hexagons, one row per person (solid = done, hatched = working on it, dashed = waiting for the mentor, grey = not started); click a row for the person's panel with stage details, meeting confirmation and editable details. Also stuck people, a funnel per stage (completed, in progress, median days), personal invite links with buddy and start date, editing an employee's track/buddy/start date.
- **Insights**
  - *Knowledge gaps*: questions the materials do not answer and answers marked 👎. *Draft section* writes a section from a gap straight into the content editor; saving marks it resolved.
  - *Quiz analytics*: per question % right, how well it separates strong and weak people, which options nobody picks. Meaningful from about 10 people.
  - *Retention*: accuracy in spaced reviews per stage.
  - *AI usage*: cost per day, purpose and model, today's spend against the budget, recent errors.
- **Content** — text sections are written in Markdown with a toolbar (bold, lists, headings, links, tables, callouts, status pills), Ctrl+B / Ctrl+I and a live preview of what employees see; a glossary editor with AI suggestions; edit, add, reorder and delete stages; tracks; first-month milestones; quizzes; AI generation of questions (checked by a second AI pass) and sections; version history with compare and restore.
- **Assistant** — provider, keys, model and fallback model, **privacy mode**, daily budget; the system prompt with version history and a try-it box; **control questions** that grade the assistant after every prompt or model change.
- **Settings** — dashboard accounts, invite-only and allowed email domains, Telegram notifications, audit log.

## AI provider

1. Get a key at https://openrouter.ai/keys.
2. Dashboard → **Assistant** → provider *OpenRouter* → paste the key → **Save and test connection**.

Default model `anthropic/claude-haiku-4.5`. **Privacy mode** (on by default) routes only to providers with zero data retention
that do not collect data; data still reaches the provider to be processed. With no key, or when the daily budget is used up,
the assistant answers from a built-in knowledge base. Keys saved in the dashboard live in `data/onboarding.db` on this machine.

## Telegram notifications

Create a bot with @BotFather, add it to the mentor chat, then in **Settings** paste the bot token and the chat ID and press
*Send a test message*. You get a message when someone requests a mentor meeting, finishes onboarding, or has made no progress
for the number of days you set (checked every 30 minutes).

## Files

| File | What it is |
|---|---|
| `server.py` | HTTP server and startup |
| `core.py` | Content model, database schema and migrations, settings |
| `llm.py` | OpenRouter / Anthropic, cost logging, budget, knowledge base |
| `employee_api.py` | Sign-in, stages, quizzes, reviews, milestones, assistant |
| `admin_api.py` | Dashboard API |
| `notify.py` | Telegram |
| `content.json` | All stages, quizzes, tracks, milestones (edited from the dashboard) |
| `static/index.html`, `static/admin.html` | The two pages |
| `data/` | Database and content history (keep it private, do not commit) |

## Settings via environment (optional)

`FIRAN_PORT`, `FIRAN_HOST` (`0.0.0.0` opens it to your network), `FIRAN_ADMIN_TOKEN` (fixed owner token), `FIRAN_DB`,
`OPENROUTER_API_KEY`, `ANTHROPIC_API_KEY`, `FIRAN_OPENROUTER_MODEL`, `FIRAN_MODEL`.

## Limitations

Employees sign in by email without a password (use invite-only and allowed domains to restrict who can start); this is
meant for a local or internal network. Before exposing it to the internet, put it behind HTTPS and company SSO.
