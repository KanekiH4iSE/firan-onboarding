@echo off
rem Windows: double-click to start the server and open the onboarding in your browser.
chcp 65001 >nul
cd /d "%~dp0"
set "PY="
where py >nul 2>nul && set "PY=py"
if not defined PY ( python --version >nul 2>nul && set "PY=python" )
if not defined PY (
  echo Python was not found. Install it from https://www.python.org/downloads/
  echo During setup, tick "Add python.exe to PATH", then run start.bat again.
  pause
  exit /b 1
)
start "" cmd /c "timeout /t 2 >nul & start http://localhost:8000"
%PY% server.py
pause
