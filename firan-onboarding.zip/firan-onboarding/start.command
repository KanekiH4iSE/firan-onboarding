#!/bin/bash
# macOS / Linux: double-click to start the server and open the onboarding in your browser.
cd "$(dirname "$0")"
( sleep 1.5; open "http://localhost:8000" 2>/dev/null || xdg-open "http://localhost:8000" ) &
python3 server.py
