"""API used by employees: sign-in, stages, quizzes, reviews, first-month plan and the assistant."""

import json
import secrets
from datetime import timedelta

import notify
from core import (CONTENT, EMAIL_RE, PASS_SCORE, ApiError, completed_keys, flag, load_progress, load_settings, now,
                  route, schedule_after, utcnow)
from llm import LLMError, ask_assistant, kb_answer, log_fallback, resolve_llm

ASSISTANT_LIMIT, ASSISTANT_WINDOW_MIN = 30, 10


def user_dict(u):
    return {"id": u["id"], "name": u["name"], "email": u["email"], "track": u["track"],
            "buddy": u["buddy"], "startDate": u["start_date"], "createdAt": u["created_at"]}


def milestones_done(conn, uid):
    return {r["milestone_id"]: r["done_at"] for r in conn.execute(
        "SELECT milestone_id, done_at FROM user_milestones WHERE user_id = ?", (uid,))}


def review_summary(conn, uid):
    n = now()
    due = conn.execute("SELECT COUNT(*) FROM reviews WHERE user_id = ? AND due_at IS NOT NULL AND due_at <= ?", (uid, n)).fetchone()[0]
    nxt = conn.execute("SELECT MIN(due_at) FROM reviews WHERE user_id = ? AND due_at > ?", (uid, n)).fetchone()[0]
    total = conn.execute("SELECT COUNT(*) FROM reviews WHERE user_id = ?", (uid,)).fetchone()[0]
    return {"due": due, "next": nxt, "total": total}


def me_payload(conn, u):
    return {"user": user_dict(u), "progress": load_progress(conn, u["id"]),
            "milestones": milestones_done(conn, u["id"]), "reviews": review_summary(conn, u["id"])}


def visible_stage(conn, user, key):
    """Returns (stage, position) if the user may act on it; raises otherwise."""
    stages = CONTENT.visible(user["track"])
    for pos, st in enumerate(stages):
        if st["key"] == key:
            if pos > 0 and stages[pos - 1]["key"] not in completed_keys(conn, user["id"]):
                raise ApiError(409, "This stage unlocks once you complete the previous one.")
            return st, pos
    raise ApiError(404, "No such stage.")


def ensure_row(conn, uid, key):
    conn.execute("INSERT OR IGNORE INTO progress (user_id, stage_key) VALUES (?, ?)", (uid, key))


# ─────────────────────────────────────────────
# Public
# ─────────────────────────────────────────────
@route("GET", r"/api/content", auth=None)
def get_content(h, conn, user, body, token=None):
    s = load_settings(conn)
    data = CONTENT.public()
    data["assistantMode"] = "kb" if resolve_llm(s)[0] == "kb" else "llm"
    data["inviteOnly"] = flag(s, "invite_only")
    return data


@route("GET", r"/api/invites/([A-Za-z0-9_-]{8,64})", auth=None)
def get_invite(h, conn, user, body, tok, token=None):
    r = conn.execute("SELECT * FROM invites WHERE token = ?", (tok,)).fetchone()
    if not r:
        raise ApiError(404, "This invite link is not valid. Ask your mentor for a new one.")
    return {"name": r["name"] or "", "email": r["email"] or "", "track": r["track"] or "", "used": bool(r["used_at"])}


@route("POST", r"/api/session", auth=None)
def create_session(h, conn, user, body, token=None):
    s = load_settings(conn)
    name = str(body.get("name", "")).strip()
    email = str(body.get("email", "")).strip().lower()
    if not 1 <= len(name) <= 80:
        raise ApiError(400, "Enter your name.")
    if not EMAIL_RE.match(email) or len(email) > 120:
        raise ApiError(400, "Enter your work email.")
    domains = [d.strip().lower().lstrip("@") for d in s["allowed_domains"].split(",") if d.strip()]
    if domains and email.split("@")[-1] not in domains:
        raise ApiError(403, f"Use your work email ({', '.join('@' + d for d in domains)}).")

    invite = None
    code = str(body.get("invite") or "").strip()
    if code:
        invite = conn.execute("SELECT * FROM invites WHERE token = ?", (code,)).fetchone()
        if not invite:
            raise ApiError(404, "This invite link is not valid. Ask your mentor for a new one.")
        if invite["used_at"] and invite["email"] and invite["email"].lower() != email:
            raise ApiError(409, "This invite link has already been used.")

    row = conn.execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()
    if row is None:
        if flag(s, "invite_only") and not invite:
            raise ApiError(403, "Onboarding is by invitation. Ask your mentor for your personal link.")
        tracks = CONTENT.tracks
        track = (invite["track"] if invite and invite["track"] else str(body.get("track") or "").strip()) or None
        if tracks and track not in tracks:
            raise ApiError(400, "Choose your track.")
        cur = conn.execute(
            "INSERT INTO users (name, email, created_at, last_seen, track, buddy, start_date) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (name, email, now(), now(), track if tracks else None,
             invite["buddy"] if invite else None, invite["start_date"] if invite else None))
        uid = cur.lastrowid
    else:
        uid = row["id"]
    if invite and not invite["used_at"]:
        conn.execute("UPDATE invites SET used_at = ?, used_by = ? WHERE token = ?", (now(), uid, invite["token"]))
    tok = secrets.token_urlsafe(24)
    conn.execute("INSERT INTO sessions (token, user_id, created_at) VALUES (?, ?, ?)", (tok, uid, now()))
    u = conn.execute("SELECT * FROM users WHERE id = ?", (uid,)).fetchone()
    return 201, {"token": tok, **me_payload(conn, u)}


# ─────────────────────────────────────────────
# Employee
# ─────────────────────────────────────────────
@route("DELETE", r"/api/session")
def delete_session(h, conn, user, body, token=None):
    conn.execute("DELETE FROM sessions WHERE token = ?", (token,))
    return {"ok": True}


@route("GET", r"/api/me")
def me(h, conn, user, body, token=None):
    return me_payload(conn, user)


@route("POST", r"/api/stages/([a-z0-9-]+)/test")
def submit_test(h, conn, user, body, key, token=None):
    st, _ = visible_stage(conn, user, key)
    questions = CONTENT.test_questions(key)
    if not questions:
        raise ApiError(400, "This stage has no quiz.")
    answers = body.get("answers")
    if not isinstance(answers, list) or len(answers) != len(questions):
        raise ApiError(400, "Send an answer for every question.")
    answers = [a if isinstance(a, int) and not isinstance(a, bool) else None for a in answers]
    results = [a == q["correct"] for a, q in zip(answers, questions)]
    correct = sum(results)
    score = round(correct / len(questions) * 100)
    passed = score >= PASS_SCORE
    conn.execute("INSERT INTO test_attempts (user_id, stage_key, answers, score, created_at) VALUES (?, ?, ?, ?, ?)",
                 (user["id"], key, json.dumps({q["id"]: a for q, a in zip(questions, answers)}), score, now()))
    ensure_row(conn, user["id"], key)
    if passed:
        conn.execute("UPDATE progress SET test_passed = 1, test_score = MAX(COALESCE(test_score, 0), ?) "
                     "WHERE user_id = ? AND stage_key = ?", (score, user["id"], key))
        first_due = schedule_after(0)
        for q in questions:   # start spaced review of this stage's questions
            conn.execute("INSERT OR IGNORE INTO reviews (user_id, qid, stage_key, box, due_at) VALUES (?, ?, ?, 0, ?)",
                         (user["id"], q["id"], key, first_due))
    return {"results": results, "correct": correct, "total": len(questions), "score": score,
            "passed": passed, "progress": load_progress(conn, user["id"])}


@route("POST", r"/api/stages/([a-z0-9-]+)/mentor")
def request_mentor(h, conn, user, body, key, token=None):
    st, _ = visible_stage(conn, user, key)
    if st["verificationMethod"] != "mentor":
        raise ApiError(400, "This stage is not signed off by a mentor.")
    ensure_row(conn, user["id"], key)
    conn.execute("UPDATE progress SET mentor_requested_at = COALESCE(mentor_requested_at, ?) "
                 "WHERE user_id = ? AND stage_key = ?", (now(), user["id"], key))
    notify.event("mentor_request", f"{user['id']}:{key}",
                 f"📅 {user['name']} requested a mentor meeting for “{st['title']}”. Confirm it in the dashboard after you meet.")
    return {"progress": load_progress(conn, user["id"])}


@route("POST", r"/api/stages/([a-z0-9-]+)/complete")
def complete_stage(h, conn, user, body, key, token=None):
    st, pos = visible_stage(conn, user, key)
    uid = user["id"]
    ensure_row(conn, uid, key)
    row = conn.execute("SELECT * FROM progress WHERE user_id = ? AND stage_key = ?", (uid, key)).fetchone()
    method = st["verificationMethod"]
    if method == "test" and not row["test_passed"]:
        raise ApiError(409, f"Pass the knowledge check at the bottom of the page with {PASS_SCORE}% or more first.")
    if method == "mentor" and not row["mentor_confirmed_at"]:
        if row["mentor_requested_at"]:
            raise ApiError(409, "Request sent. The stage completes once your mentor confirms the meeting.")
        raise ApiError(409, "Your mentor signs off this stage. Request a meeting at the bottom of the page.")
    if not row["completed_at"]:
        conn.execute("UPDATE progress SET completed_at = ? WHERE user_id = ? AND stage_key = ?", (now(), uid, key))
        if pos == len(CONTENT.visible(user["track"])) - 1:
            notify.event("completed", str(uid), f"🎉 {user['name']} completed onboarding.")
    return {"progress": load_progress(conn, uid)}


@route("POST", r"/api/dossier/verdict")
def dossier_verdict(h, conn, user, body, token=None):
    verdict = body.get("verdict")
    if verdict not in ("Confirmed", "Dismissed", "Data requested"):
        raise ApiError(400, "Unknown verdict.")
    conn.execute("INSERT INTO dossier_verdicts (user_id, verdict, updated_at) VALUES (?, ?, ?) "
                 "ON CONFLICT(user_id) DO UPDATE SET verdict = excluded.verdict, updated_at = excluded.updated_at",
                 (user["id"], verdict, now()))
    return {"progress": load_progress(conn, user["id"])}


@route("POST", r"/api/progress/reset")
def reset_progress(h, conn, user, body, token=None):
    uid = user["id"]
    for table in ("progress", "dossier_verdicts", "reviews", "user_milestones"):
        conn.execute(f"DELETE FROM {table} WHERE user_id = ?", (uid,))
    return me_payload(conn, user)


# ─────────────────────────────────────────────
# First-month plan
# ─────────────────────────────────────────────
@route("POST", r"/api/milestones/([a-z0-9]+)")
def toggle_milestone(h, conn, user, body, mid, token=None):
    if mid not in {m["id"] for m in CONTENT.get().get("milestones", [])}:
        raise ApiError(404, "No such milestone.")
    if body.get("done"):
        conn.execute("INSERT OR IGNORE INTO user_milestones (user_id, milestone_id, done_at) VALUES (?, ?, ?)", (user["id"], mid, now()))
    else:
        conn.execute("DELETE FROM user_milestones WHERE user_id = ? AND milestone_id = ?", (user["id"], mid))
    return {"milestones": milestones_done(conn, user["id"])}


# ─────────────────────────────────────────────
# Spaced review
# ─────────────────────────────────────────────
@route("GET", r"/api/reviews")
def reviews_due(h, conn, user, body, token=None):
    qindex = CONTENT.question_index()
    rows = conn.execute("SELECT * FROM reviews WHERE user_id = ? AND due_at IS NOT NULL AND due_at <= ? ORDER BY box, due_at",
                        (user["id"], now())).fetchall()
    items = []
    for r in rows:
        if r["qid"] not in qindex:
            conn.execute("DELETE FROM reviews WHERE user_id = ? AND qid = ?", (user["id"], r["qid"]))
            continue
        st, q = qindex[r["qid"]]
        items.append({"qid": q["id"], "question": q["question"], "options": q["options"], "stage": st["title"], "box": r["box"]})
        if len(items) == 5:
            break
    return {"items": items, **review_summary(conn, user["id"])}


@route("POST", r"/api/reviews/answer")
def review_answer(h, conn, user, body, token=None):
    qid = str(body.get("qid", ""))
    r = conn.execute("SELECT * FROM reviews WHERE user_id = ? AND qid = ?", (user["id"], qid)).fetchone()
    found = CONTENT.question_index().get(qid)
    if not r or not found:
        raise ApiError(404, "This review question is no longer available.")
    st, q = found
    choice = body.get("choice")
    ok = isinstance(choice, int) and not isinstance(choice, bool) and choice == q["correct"]
    box = min(r["box"] + 1, 5) if ok else 0
    conn.execute("UPDATE reviews SET box = ?, due_at = ?, last_at = ? WHERE user_id = ? AND qid = ?",
                 (box, schedule_after(box), now(), user["id"], qid))
    conn.execute("INSERT INTO review_log (user_id, qid, stage_key, correct, created_at) VALUES (?, ?, ?, ?, ?)",
                 (user["id"], qid, st["key"], 1 if ok else 0, now()))
    return {"correct": ok, "correctIndex": q["correct"], "src": q.get("src"), "box": box,
            "mastered": box >= 5, "summary": review_summary(conn, user["id"])}


# ─────────────────────────────────────────────
# Assistant
# ─────────────────────────────────────────────
@route("GET", r"/api/assistant/history")
def assistant_history(h, conn, user, body, token=None):
    rows = conn.execute("SELECT id, role, text, src, rating FROM (SELECT * FROM chat_messages WHERE user_id = ? "
                        "ORDER BY id DESC LIMIT 30) ORDER BY id", (user["id"],)).fetchall()
    return {"messages": [dict(r) for r in rows]}


@route("POST", r"/api/assistant")
def assistant(h, conn, user, body, token=None):
    question = str(body.get("question", "")).strip()
    if not question:
        raise ApiError(400, "The question is empty.")
    if len(question) > 1000:
        raise ApiError(400, "The question is too long: 1000 characters maximum.")
    since = (utcnow() - timedelta(minutes=ASSISTANT_WINDOW_MIN)).isoformat(timespec="seconds")
    recent = conn.execute("SELECT COUNT(*) FROM chat_messages WHERE user_id = ? AND role = 'user' AND created_at > ?",
                          (user["id"], since)).fetchone()[0]
    if recent >= ASSISTANT_LIMIT:
        raise ApiError(429, "Too many questions in a row. Try again in a few minutes.")
    history = [{"role": r["role"], "content": r["text"]} for r in conn.execute(
        "SELECT role, text FROM (SELECT * FROM chat_messages WHERE user_id = ? ORDER BY id DESC LIMIT 6) ORDER BY id", (user["id"],))]
    while history and history[0]["role"] != "user":
        history.pop(0)

    s = load_settings(conn)
    conn.commit()   # release the write lock before a slow network call
    mode = "kb"
    if resolve_llm(s)[0] != "kb":
        try:
            text, src, unanswered, _, _ = ask_assistant(s, history, question, user_id=user["id"])
            mode = "llm"
        except LLMError as e:
            log_fallback(e)
            text, src, unanswered = kb_answer(question)
    else:
        text, src, unanswered = kb_answer(question)

    ts = now()
    conn.execute("INSERT INTO chat_messages (user_id, role, text, created_at) VALUES (?, 'user', ?, ?)", (user["id"], question, ts))
    cur = conn.execute("INSERT INTO chat_messages (user_id, role, text, src, created_at, question, unanswered) "
                       "VALUES (?, 'assistant', ?, ?, ?, ?, ?)", (user["id"], text, src, ts, question, 1 if unanswered else 0))
    return {"id": cur.lastrowid, "text": text, "src": src, "mode": mode}


@route("POST", r"/api/assistant/rate")
def assistant_rate(h, conn, user, body, token=None):
    mid, rating = body.get("messageId"), body.get("rating")
    if rating not in (1, -1, 0) or not isinstance(mid, int):
        raise ApiError(400, "Invalid rating.")
    cur = conn.execute("UPDATE chat_messages SET rating = ? WHERE id = ? AND user_id = ? AND role = 'assistant'",
                       (rating or None, mid, user["id"]))
    if not cur.rowcount:
        raise ApiError(404, "Message not found.")
    return {"ok": True}
