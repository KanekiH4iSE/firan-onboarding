"""Telegram notifications for mentors: meeting requests, completions and employees who are stuck."""

import json
import os
import sys
import threading
import time
import urllib.error
import urllib.request

from core import CONTENT, connect, load_settings, next_stage, now, num, parse_ts, utcnow

TELEGRAM_API = os.environ.get("FIRAN_TELEGRAM_URL", "https://api.telegram.org")
WATCH_EVERY_SEC = int(os.environ.get("FIRAN_WATCH_SECONDS", "1800"))


def configured(s):
    return bool(s["telegram_token"].strip() and s["telegram_chat_id"].strip())


def send(s, text):
    """Sends one message. Returns (ok, error)."""
    if not configured(s):
        return False, "Telegram is not configured."
    url = f"{TELEGRAM_API}/bot{s['telegram_token'].strip()}/sendMessage"
    body = json.dumps({"chat_id": s["telegram_chat_id"].strip(), "text": text,
                       "disable_web_page_preview": True}).encode("utf-8")
    req = urllib.request.Request(url, data=body, headers={"Content-Type": "application/json"}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.load(resp)
        return (True, None) if data.get("ok") else (False, data.get("description", "Telegram refused the message."))
    except urllib.error.HTTPError as e:
        try:
            desc = json.loads(e.read().decode("utf-8", "replace")).get("description", "")
        except ValueError:
            desc = ""
        return False, f"Telegram returned HTTP {e.code}" + (f": {desc}" if desc else ".")
    except (urllib.error.URLError, TimeoutError, OSError) as e:
        return False, f"Could not reach Telegram: {getattr(e, 'reason', e)}"


def _claim(conn, kind, ref):
    """Records that a notification was sent; False if it was sent before."""
    cur = conn.execute("INSERT OR IGNORE INTO notified (kind, ref, created_at) VALUES (?, ?, ?)", (kind, ref, now()))
    conn.commit()
    return cur.rowcount == 1


def event(kind, ref, text):
    """Fire-and-forget notification, sent once per (kind, ref)."""
    def run():
        conn = connect()
        try:
            s = load_settings(conn)
            if not configured(s) or not _claim(conn, kind, ref):
                return
            ok, err = send(s, text)
            if not ok:
                sys.stderr.write(f"  ! Telegram: {err}\n")
        finally:
            conn.close()
    threading.Thread(target=run, daemon=True).start()


def check_stuck():
    """Notifies about employees who have not completed a stage for N days. Returns how many were reported."""
    conn = connect()
    reported = 0
    try:
        s = load_settings(conn)
        days = num(s, "notify_stuck_days")
        if not configured(s) or not days or days <= 0:
            return 0
        for u in conn.execute("SELECT * FROM users").fetchall():
            st = next_stage(conn, u)
            if st is None:
                continue
            last = conn.execute("SELECT MAX(completed_at) FROM progress WHERE user_id = ?", (u["id"],)).fetchone()[0]
            since = parse_ts(last or u["created_at"])
            if not since:
                continue
            idle = (utcnow() - since).total_seconds() / 86400
            if idle >= days and _claim(conn, "stuck", f"{u['id']}:{st['key']}"):
                ok, err = send(s, f"⏳ {u['name']} has been on “{st['title']}” for {int(idle)} days without progress.")
                reported += 1 if ok else 0
                if not ok:
                    sys.stderr.write(f"  ! Telegram: {err}\n")
    finally:
        conn.close()
    return reported


def start_watcher():
    def loop():
        while True:
            try:
                check_stuck()
            except Exception as e:  # noqa: BLE001 – the watcher must never die
                sys.stderr.write(f"  ! stuck-check failed: {e}\n")
            time.sleep(WATCH_EVERY_SEC)
    threading.Thread(target=loop, daemon=True).start()
