"""Mentor dashboard API. Roles: mentor < editor < owner. The server token printed at startup acts as owner."""

import html
import json
import random
import re
import secrets
import statistics
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone

import notify
from core import (ADMIN_TOKEN, CONTENT, EMAIL_RE, HISTORY_DIR, ROLE_RANK, ApiError, audit, check_password, flag,
                  hash_password, load_settings, next_stage, now, num, parse_ts, route, save_settings, slugify, text,
                  utcnow, write_content, new_id)
from llm import (DEFAULT_SYSTEM_PROMPT, ENV_ANTHROPIC_KEY, ENV_OPENROUTER_KEY, PROVIDER_LABEL, PROVIDERS, LLMError,
                 ask_assistant, extract_json, llm_complete, resolve_llm, spend_today, system_prompt_of)

OWNER_TOKEN_ACTOR = {"id": 0, "name": "Owner (server token)", "email": None, "role": "owner"}


def resolve_admin(conn, token):
    if token and secrets.compare_digest(token, ADMIN_TOKEN):
        return OWNER_TOKEN_ACTOR
    if not token:
        return None
    r = conn.execute("SELECT a.* FROM admin_sessions s JOIN admins a ON a.id = s.admin_id WHERE s.token = ?", (token,)).fetchone()
    return {"id": r["id"], "name": r["name"], "email": r["email"], "role": r["role"]} if r else None


def days_between(a, b):
    ta, tb = parse_ts(a), parse_ts(b)
    return (tb - ta).total_seconds() / 86400 if ta and tb else None


# ─────────────────────────────────────────────
# Sign-in and accounts
# ─────────────────────────────────────────────
@route("POST", r"/api/admin/login", auth=None)
def admin_login(h, conn, actor, body, token=None):
    email = str(body.get("email", "")).strip().lower()
    r = conn.execute("SELECT * FROM admins WHERE email = ?", (email,)).fetchone()
    if not r or not check_password(str(body.get("password", "")), r["pw_hash"]):
        time.sleep(0.5)
        raise ApiError(403, "Wrong email or password.")
    tok = secrets.token_urlsafe(24)
    conn.execute("INSERT INTO admin_sessions (token, admin_id, created_at) VALUES (?, ?, ?)", (tok, r["id"], now()))
    conn.execute("UPDATE admins SET last_login = ? WHERE id = ?", (now(), r["id"]))
    return {"token": tok, "admin": {"name": r["name"], "email": r["email"], "role": r["role"]}}


@route("GET", r"/api/admin/me", auth="admin")
def admin_me(h, conn, actor, body, token=None):
    return {"admin": actor}


@route("POST", r"/api/admin/logout", auth="admin")
def admin_logout(h, conn, actor, body, token=None):
    conn.execute("DELETE FROM admin_sessions WHERE token = ?", (token,))
    return {"ok": True}


@route("GET", r"/api/admin/accounts", auth="admin", role="owner")
def list_accounts(h, conn, actor, body, token=None):
    rows = conn.execute("SELECT id, email, name, role, created_at, last_login FROM admins ORDER BY id").fetchall()
    return {"accounts": [dict(r) for r in rows]}


@route("POST", r"/api/admin/accounts", auth="admin", role="owner")
def create_account(h, conn, actor, body, token=None):
    name = text(body.get("name"), "Account", "name", max_len=80)
    email = text(body.get("email"), "Account", "email", max_len=120).lower()
    role = body.get("role")
    pw = str(body.get("password") or "")
    if not EMAIL_RE.match(email):
        raise ApiError(400, "Account: enter a valid email.")
    if role not in ROLE_RANK:
        raise ApiError(400, "Account: unknown role.")
    if len(pw) < 10:
        raise ApiError(400, "Account: the password needs at least 10 characters.")
    if conn.execute("SELECT 1 FROM admins WHERE email = ?", (email,)).fetchone():
        raise ApiError(409, "An account with this email already exists.")
    conn.execute("INSERT INTO admins (email, name, role, pw_hash, created_at) VALUES (?, ?, ?, ?, ?)",
                 (email, name, role, hash_password(pw), now()))
    audit(conn, actor, "account.create", f"{email} as {role}")
    return list_accounts(h, conn, actor, body)


@route("DELETE", r"/api/admin/accounts/(\d+)", auth="admin", role="owner")
def delete_account(h, conn, actor, body, aid, token=None):
    r = conn.execute("SELECT email FROM admins WHERE id = ?", (int(aid),)).fetchone()
    if not r:
        raise ApiError(404, "No such account.")
    if actor["id"] == int(aid):
        raise ApiError(409, "You cannot delete your own account.")
    conn.execute("DELETE FROM admins WHERE id = ?", (int(aid),))
    audit(conn, actor, "account.delete", r["email"])
    return list_accounts(h, conn, actor, body)


@route("GET", r"/api/admin/audit", auth="admin", role="owner")
def audit_list(h, conn, actor, body, token=None):
    rows = conn.execute("SELECT created_at, actor, action, detail FROM audit_log ORDER BY id DESC LIMIT 300").fetchall()
    return {"entries": [dict(r) for r in rows]}


# ─────────────────────────────────────────────
# Team, funnel, employees
# ─────────────────────────────────────────────
@route("GET", r"/api/admin/overview", auth="admin")
def admin_overview(h, conn, actor, body, token=None):
    s = load_settings(conn)
    stuck_days = num(s, "notify_stuck_days") or 3
    stages = CONTENT.stages
    milestones = CONTENT.get().get("milestones", [])
    users, funnel = [], {st["key"]: {"key": st["key"], "title": st["title"], "eligible": 0, "completed": 0, "here": 0, "days": []} for st in stages}
    for u in conn.execute("SELECT * FROM users ORDER BY COALESCE(last_seen, created_at) DESC").fetchall():
        prog = {r["stage_key"]: r for r in conn.execute("SELECT * FROM progress WHERE user_id = ?", (u["id"],))}
        attempts = {r["stage_key"]: r for r in conn.execute(
            "SELECT stage_key, COUNT(*) AS n, MAX(score) AS best FROM test_attempts WHERE user_id = ? GROUP BY stage_key", (u["id"],))}
        visible = [st["key"] for st in CONTENT.visible(u["track"])]
        nxt = next_stage(conn, u)
        prev_done = u["created_at"]
        cells = []
        for st in stages:
            p = prog.get(st["key"])
            in_track = st["key"] in visible
            if in_track:
                f = funnel[st["key"]]
                f["eligible"] += 1
                if p and p["completed_at"]:
                    f["completed"] += 1
                    d = days_between(prev_done, p["completed_at"])
                    if d is not None:
                        f["days"].append(max(d, 0))
                    prev_done = p["completed_at"]
                if nxt and nxt["key"] == st["key"]:
                    f["here"] += 1
            cells.append({
                "key": st["key"], "title": st["title"], "method": st["verificationMethod"], "inTrack": in_track,
                "completed": bool(p and p["completed_at"]),
                "testScore": attempts[st["key"]]["best"] if st["key"] in attempts else None,
                "attempts": attempts[st["key"]]["n"] if st["key"] in attempts else 0,
                "mentor": ("confirmed" if p and p["mentor_confirmed_at"] else "requested" if p and p["mentor_requested_at"] else None),
                "mentorRequestedAt": p["mentor_requested_at"] if p else None,
            })
        last = conn.execute("SELECT MAX(completed_at) FROM progress WHERE user_id = ?", (u["id"],)).fetchone()[0]
        idle = days_between(last or u["created_at"], now())
        rv = conn.execute("SELECT COUNT(*), COALESCE(SUM(correct), 0) FROM review_log WHERE user_id = ?", (u["id"],)).fetchone()
        done_ms = conn.execute("SELECT COUNT(*) FROM user_milestones WHERE user_id = ?", (u["id"],)).fetchone()[0]
        users.append({
            "id": u["id"], "name": u["name"], "email": u["email"], "track": u["track"], "buddy": u["buddy"],
            "startDate": u["start_date"], "createdAt": u["created_at"], "lastSeen": u["last_seen"],
            "completed": sum(1 for c in cells if c["completed"] and c["inTrack"]), "total": len(visible),
            "finished": nxt is None, "current": nxt["title"] if nxt else None,
            "idleDays": round(idle, 1) if idle is not None else None,
            "stuck": bool(nxt and idle is not None and idle >= stuck_days),
            "stages": cells, "milestonesDone": done_ms, "milestonesTotal": len(milestones),
            "reviewAnswers": rv[0], "reviewCorrect": rv[1],
            "assistantQuestions": conn.execute("SELECT COUNT(*) FROM chat_messages WHERE user_id = ? AND role = 'user'", (u["id"],)).fetchone()[0],
        })
    funnel_out = []
    for st in stages:
        f = funnel[st["key"]]
        funnel_out.append({k: f[k] for k in ("key", "title", "eligible", "completed", "here")} |
                          {"medianDays": round(statistics.median(f["days"]), 1) if f["days"] else None})
    return {"stages": [{"key": st["key"], "title": st["title"], "tracks": st.get("tracks", [])} for st in stages],
            "tracks": CONTENT.tracks, "users": users, "funnel": funnel_out, "stuckDays": stuck_days}


@route("POST", r"/api/admin/mentor/confirm", auth="admin")
def admin_confirm(h, conn, actor, body, token=None):
    try:
        uid = int(body.get("userId"))
    except (TypeError, ValueError):
        raise ApiError(400, "userId is required.")
    key = str(body.get("stageKey", ""))
    row = conn.execute("SELECT mentor_requested_at FROM progress WHERE user_id = ? AND stage_key = ?", (uid, key)).fetchone()
    if not row or not row["mentor_requested_at"]:
        raise ApiError(409, "This employee has not requested a meeting for this stage yet.")
    conn.execute("UPDATE progress SET mentor_confirmed_at = COALESCE(mentor_confirmed_at, ?) WHERE user_id = ? AND stage_key = ?",
                 (now(), uid, key))
    audit(conn, actor, "mentor.confirm", f"user {uid}, stage {key}")
    return {"ok": True}


@route("POST", r"/api/admin/users/(\d+)", auth="admin", role="editor")
def update_user(h, conn, actor, body, uid, token=None):
    u = conn.execute("SELECT * FROM users WHERE id = ?", (int(uid),)).fetchone()
    if not u:
        raise ApiError(404, "No such employee.")
    track = str(body.get("track", u["track"] or "")).strip() or None
    if track and track not in CONTENT.tracks:
        raise ApiError(400, "Unknown track.")
    buddy = text(body.get("buddy", u["buddy"] or ""), "Employee", "buddy", required=False, max_len=120) or None
    start = text(body.get("startDate", u["start_date"] or ""), "Employee", "start date", required=False, max_len=10) or None
    conn.execute("UPDATE users SET track = ?, buddy = ?, start_date = ? WHERE id = ?", (track, buddy, start, int(uid)))
    audit(conn, actor, "employee.update", f"{u['email']}: track={track}, buddy={buddy}, start={start}")
    return {"ok": True}


@route("DELETE", r"/api/admin/users/(\d+)", auth="admin", role="owner")
def delete_user(h, conn, actor, body, uid, token=None):
    u = conn.execute("SELECT email FROM users WHERE id = ?", (int(uid),)).fetchone()
    if not u:
        raise ApiError(404, "No such employee.")
    conn.execute("DELETE FROM users WHERE id = ?", (int(uid),))
    audit(conn, actor, "employee.delete", u["email"])
    return {"ok": True}


@route("GET", r"/api/admin/users/(\d+)/chat", auth="admin")
def admin_chat(h, conn, actor, body, uid, token=None):
    rows = conn.execute("SELECT role, text, src, created_at, unanswered, rating FROM chat_messages WHERE user_id = ? ORDER BY id",
                        (int(uid),)).fetchall()
    return {"messages": [dict(r) for r in rows]}


# ─────────────────────────────────────────────
# Invites
# ─────────────────────────────────────────────
@route("GET", r"/api/admin/invites", auth="admin", role="editor")
def list_invites(h, conn, actor, body, token=None):
    rows = conn.execute("SELECT i.*, u.name AS used_name FROM invites i LEFT JOIN users u ON u.id = i.used_by "
                        "ORDER BY i.created_at DESC LIMIT 200").fetchall()
    return {"invites": [dict(r) for r in rows]}


@route("POST", r"/api/admin/invites", auth="admin", role="editor")
def create_invite(h, conn, actor, body, token=None):
    name = text(body.get("name"), "Invite", "name", required=False, max_len=80)
    email = text(body.get("email"), "Invite", "email", required=False, max_len=120).lower()
    if email and not EMAIL_RE.match(email):
        raise ApiError(400, "Invite: enter a valid email or leave it empty.")
    track = str(body.get("track") or "").strip() or None
    if track and track not in CONTENT.tracks:
        raise ApiError(400, "Invite: unknown track.")
    buddy = text(body.get("buddy"), "Invite", "buddy", required=False, max_len=120) or None
    start = text(body.get("startDate"), "Invite", "start date", required=False, max_len=10) or None
    tok = secrets.token_urlsafe(16)
    conn.execute("INSERT INTO invites (token, name, email, track, buddy, start_date, created_at, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                 (tok, name or None, email or None, track, buddy, start, now(), actor["name"]))
    audit(conn, actor, "invite.create", email or name or tok[:6])
    return {"token": tok, **list_invites(h, conn, actor, body)}


@route("DELETE", r"/api/admin/invites/([A-Za-z0-9_-]{8,64})", auth="admin", role="editor")
def revoke_invite(h, conn, actor, body, tok, token=None):
    conn.execute("DELETE FROM invites WHERE token = ? AND used_at IS NULL", (tok,))
    audit(conn, actor, "invite.revoke", tok[:6])
    return list_invites(h, conn, actor, body)


# ─────────────────────────────────────────────
# Content editor
# ─────────────────────────────────────────────
SECTION_TYPES = {"note", "text", "layers", "flow", "er", "dossier", "gantt", "test", "mentor"}
HISTORY_RE = re.compile(r"^content-\d{8}-\d{6}(-\d+)?\.json$")
KEY_RE = re.compile(r"^[a-z0-9][a-z0-9-]{0,39}$")


def validate_question(q, where, seen_ids=None):
    if not isinstance(q, dict):
        raise ApiError(400, f"{where}: invalid question.")
    opts = q.get("options")
    if not isinstance(opts, list) or not 2 <= len(opts) <= 6:
        raise ApiError(400, f"{where}: a question needs 2–6 options.")
    opts = [text(o, where, f"option {chr(65 + n)}", max_len=500) for n, o in enumerate(opts)]
    correct = q.get("correct")
    if not isinstance(correct, int) or isinstance(correct, bool) or not 0 <= correct < len(opts):
        raise ApiError(400, f"{where}: mark the correct answer.")
    qid = q.get("id") if isinstance(q.get("id"), str) and re.fullmatch(r"q[0-9a-f]{6}", q.get("id", "")) else None
    if seen_ids is not None:
        if not qid or qid in seen_ids:
            qid = new_id("q")
        seen_ids.add(qid)
    item = {"id": qid or new_id("q"), "question": text(q.get("question"), where, "question", max_len=600), "options": opts, "correct": correct}
    src = text(q.get("src"), where, "source", required=False, max_len=40)
    if src:
        item["src"] = src
    return item


def validate_content(c):
    if not isinstance(c, dict):
        raise ApiError(400, "Content must be a JSON object.")
    tracks = c.get("tracks") or []
    if not isinstance(tracks, list):
        raise ApiError(400, "Tracks must be a list.")
    tracks = [text(t, "Tracks", "track name", max_len=40) for t in tracks]
    if len(set(tracks)) != len(tracks) or len(tracks) > 8:
        raise ApiError(400, "Tracks: names must be unique (up to 8).")
    stages = c.get("stages")
    if not isinstance(stages, list) or not 1 <= len(stages) <= 30:
        raise ApiError(400, "Content needs 1–30 stages.")

    keys, qids, clean_stages = set(), set(), []
    for i, st in enumerate(stages):
        where = f"Stage {i + 1}"
        if not isinstance(st, dict):
            raise ApiError(400, f"{where}: invalid stage.")
        title = text(st.get("title"), where, "title", max_len=120)
        key = st.get("key") if isinstance(st.get("key"), str) and KEY_RE.match(st.get("key", "")) and st["key"] not in keys else slugify(title, keys)
        keys.add(key)
        method = st.get("verificationMethod")
        if method not in ("none", "test", "mentor"):
            raise ApiError(400, f"{where}: unknown verification method.")
        st_tracks = st.get("tracks") or []
        if not isinstance(st_tracks, list) or any(t not in tracks for t in st_tracks):
            raise ApiError(400, f"{where}: unknown track.")
        sections = st.get("sections")
        if not isinstance(sections, list):
            raise ApiError(400, f"{where}: sections are missing.")
        clean_sections = []
        for j, sec in enumerate(sections):
            sw = f"{where}, section {j + 1}"
            t = sec.get("type") if isinstance(sec, dict) else None
            if t not in SECTION_TYPES:
                raise ApiError(400, f"{sw}: unknown section type.")
            cs = {"type": t}
            if t == "note":
                cs["html"] = text(sec.get("html"), sw, "text", max_len=5000)
            elif t == "text":
                cs["heading"] = text(sec.get("heading"), sw, "heading", max_len=200)
                src = text(sec.get("src"), sw, "source", required=False, max_len=40)
                if src:
                    cs["src"] = src
                cs["content"] = text(sec.get("content"), sw, "content", max_len=50000)
                md = text(sec.get("markdown"), sw, "markdown", required=False, max_len=50000)
                if md:
                    cs["markdown"] = md
            elif t in ("layers", "flow", "dossier", "gantt"):
                cs["heading"] = text(sec.get("heading"), sw, "heading", max_len=200)
                src = text(sec.get("src"), sw, "source", required=False, max_len=40)
                if src:
                    cs["src"] = src
                if t in ("dossier", "gantt"):
                    cs["intro"] = text(sec.get("intro"), sw, "intro", required=False, max_len=2000)
            elif t == "mentor":
                cs["heading"] = text(sec.get("heading"), sw, "heading", required=False, max_len=200)
                cs["note"] = text(sec.get("note"), sw, "note", required=False, max_len=2000)
            elif t == "test":
                qs = sec.get("questions")
                if not isinstance(qs, list) or not 1 <= len(qs) <= 30:
                    raise ApiError(400, f"{sw}: a quiz needs 1–30 questions.")
                cs["questions"] = [validate_question(q, f"{where}, question {k + 1}", qids) for k, q in enumerate(qs)]
            clean_sections.append(cs)
        types = [x["type"] for x in clean_sections]
        if method == "test" and types.count("test") != 1:
            raise ApiError(400, f"{where}: a quiz stage needs exactly one quiz section.")
        if method != "test" and "test" in types:
            raise ApiError(400, f"{where}: this stage has a quiz, so set its verification to Quiz.")
        if method == "mentor" and "mentor" not in types:
            raise ApiError(400, f"{where}: a mentor stage needs a mentor section.")
        clean_stages.append({
            "key": key, "id": i + 1, "title": title, "tracks": st_tracks,
            "description": text(st.get("description"), where, "description", max_len=300),
            "timeEstimate": text(st.get("timeEstimate"), where, "time estimate", max_len=40),
            "verification": text(st.get("verification"), where, "verification label", max_len=60),
            "verificationMethod": method, "sections": clean_sections,
        })
    for tr in tracks:
        if not any(not st["tracks"] or tr in st["tracks"] for st in clean_stages):
            raise ApiError(400, f"Track “{tr}” has no stages.")

    milestones, mids = [], set()
    for k, m in enumerate(c.get("milestones") or []):
        where = f"Milestone {k + 1}"
        if not isinstance(m, dict):
            raise ApiError(400, f"{where}: invalid.")
        mid = m.get("id") if isinstance(m.get("id"), str) and re.fullmatch(r"m[0-9a-f]{6}", m.get("id", "")) and m["id"] not in mids else new_id("m")
        mids.add(mid)
        milestones.append({"id": mid, "when": text(m.get("when"), where, "when", max_len=40),
                           "title": text(m.get("title"), where, "title", max_len=200)})

    glossary, gids, seen_terms = [], set(), set()
    for k, g in enumerate(c.get("glossary") or []):
        where = f"Glossary term {k + 1}"
        if not isinstance(g, dict):
            raise ApiError(400, f"{where}: invalid.")
        term = text(g.get("term"), where, "term", max_len=60)
        if term.lower() in seen_terms:
            raise ApiError(400, f"{where}: “{term}” is listed twice.")
        seen_terms.add(term.lower())
        gid = g.get("id") if isinstance(g.get("id"), str) and re.fullmatch(r"g[0-9a-f]{6}", g.get("id", "")) and g["id"] not in gids else new_id("g")
        gids.add(gid)
        aliases = g.get("aliases") or []
        if isinstance(aliases, str):
            aliases = [a for a in aliases.split(",")]
        aliases = [a.strip() for a in aliases if isinstance(a, str) and a.strip()][:6]
        entry = {"id": gid, "term": term, "aliases": [a[:60] for a in aliases],
                 "definition": text(g.get("definition"), where, "definition", max_len=400)}
        src = text(g.get("src"), where, "source", required=False, max_len=40)
        if src:
            entry["src"] = src
        glossary.append(entry)

    m = c.get("mentor") if isinstance(c.get("mentor"), dict) else {}
    name = text(m.get("name"), "Mentor", "name", max_len=80)
    initials = text(m.get("initials"), "Mentor", "initials", required=False, max_len=4) or "".join(w[0] for w in name.split()[:2]).upper()
    notes = c.get("assistantNotes") or []
    if not isinstance(notes, list):
        raise ApiError(400, "Assistant notes must be a list.")
    return {
        "mentor": {"name": name, "role": text(m.get("role"), "Mentor", "role", required=False, max_len=120), "initials": initials,
                   "avatar": text(m.get("avatar"), "Mentor", "photo path", required=False, max_len=300)},
        "sourceDoc": text(c.get("sourceDoc"), "Content", "source document", required=False, max_len=300),
        "tracks": tracks, "milestones": milestones, "stages": clean_stages, "glossary": glossary,
        "assistantNotes": [n for n in (text(x, "Assistant notes", f"note {k + 1}", required=False, max_len=4000) for k, x in enumerate(notes)) if n],
    }


@route("GET", r"/api/admin/content", auth="admin", role="editor")
def admin_get_content(h, conn, actor, body, token=None):
    return CONTENT.get()


@route("POST", r"/api/admin/content", auth="admin", role="editor")
def admin_save_content(h, conn, actor, body, token=None):
    before = {st["key"] for st in CONTENT.stages}
    data = validate_content(body.get("content"))
    write_content(data)
    after = {st["key"] for st in data["stages"]}
    detail = []
    if after - before:
        detail.append("added " + ", ".join(sorted(after - before)))
    if before - after:
        detail.append("removed " + ", ".join(sorted(before - after)))
    audit(conn, actor, "content.save", "; ".join(detail) or "edited")
    return {"ok": True, "content": data}


@route("GET", r"/api/admin/content/history", auth="admin", role="editor")
def admin_content_history(h, conn, actor, body, token=None):
    items = []
    if HISTORY_DIR.is_dir():
        for f in sorted(HISTORY_DIR.glob("content-*.json"), reverse=True):
            items.append({"name": f.name, "savedAt": datetime.fromtimestamp(f.stat().st_mtime, timezone.utc).isoformat(timespec="seconds")})
    return {"versions": items}


@route("GET", r"/api/admin/content/history/([A-Za-z0-9.-]+)", auth="admin", role="editor")
def admin_content_version(h, conn, actor, body, name, token=None):
    f = HISTORY_DIR / name
    if not HISTORY_RE.match(name) or not f.is_file():
        raise ApiError(404, "That version no longer exists.")
    return {"content": json.loads(f.read_text(encoding="utf-8"))}


@route("POST", r"/api/admin/content/restore", auth="admin", role="editor")
def admin_content_restore(h, conn, actor, body, token=None):
    name = str(body.get("name", ""))
    f = HISTORY_DIR / name
    if not HISTORY_RE.match(name) or not f.is_file():
        raise ApiError(404, "That version no longer exists.")
    data = validate_content(json.loads(f.read_text(encoding="utf-8")))
    write_content(data)
    audit(conn, actor, "content.restore", name)
    return {"ok": True, "content": data}


# ─────────────────────────────────────────────
# AI generation (with a second verification pass)
# ─────────────────────────────────────────────
QUIZ_PROMPT = """You write knowledge-check questions for Firan's onboarding programme.
Use only facts from the material provided. Test understanding of points that matter for someone joining the team, not trivia.
Write in clear, plain English. Every question has exactly 4 options: one correct and three plausible but clearly wrong distractors of similar length and style.
Never use "all of the above" or "none of the above". Do not repeat the existing questions.
Return only JSON with no commentary: an array of objects with the keys
  "question" (string), "options" (array of 4 strings), "correct" (index 0-3 of the correct option),
  "src" (the section number from the material that contains the answer, such as "2.2", or "")."""

VERIFY_PROMPT = """You review multiple-choice questions against source material before they go into an onboarding quiz.
For each question check that: (1) the marked answer is clearly supported by the material, (2) no other option could also be
defended as correct, (3) the wording is unambiguous. Be strict but brief.
Return only JSON: an array of objects {"index": number, "ok": true|false, "issue": "one short sentence, empty if ok"}."""

SECTION_PROMPT = """You draft sections for Firan's onboarding programme.
Use only facts from the material provided; never invent figures, clients, dates or statuses.
Write in clear, plain English for someone new to the team: short paragraphs, concrete wording.
Return only JSON with no commentary:
  {"heading": string, "src": section number from the material or "", "paragraphs": [string, ...], "bullets": [string, ...]}
"bullets" may be an empty array. Use **double asterisks** for the few words that deserve bold."""


GLOSSARY_PROMPT = """You pick glossary terms for Firan's onboarding programme: words a new team member will meet and may not know.
Use only the material provided. Prefer domain terms (banking, fraud, the platform), not everyday words. Definitions: one or two plain sentences,
at most 35 words, written for a smart newcomer. Do not repeat terms already in the glossary.
Return only JSON: an array of {"term": string, "aliases": [other spellings or plural forms that appear in the text], "definition": string,
"src": section number where it is explained, or ""}."""


def _inline(t):
    return re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", html.escape(t))


def _stage_or_404(key):
    st = CONTENT.stage(str(key or ""))
    if not st:
        raise ApiError(404, "No such stage (save new stages before generating for them).")
    return st


def verify_questions(s, material, questions):
    listing = "\n\n".join(
        f"[{i}] {q['question']}\n" + "\n".join(f"  {chr(65 + n)}. {o}{'  <- marked correct' if n == q['correct'] else ''}"
                                             for n, o in enumerate(q["options"])) for i, q in enumerate(questions))
    txt, _, _ = llm_complete(s, VERIFY_PROMPT, [{"role": "user", "content": f"Material:\n{material}\n\nQuestions:\n{listing}"}], 1200, "verify")
    data = extract_json(txt)
    out = {}
    for item in data if isinstance(data, list) else []:
        if isinstance(item, dict) and isinstance(item.get("index"), int):
            out[item["index"]] = {"ok": bool(item.get("ok")), "issue": str(item.get("issue") or "")[:300]}
    return out


@route("POST", r"/api/admin/generate/quiz", auth="admin", role="editor")
def admin_generate_quiz(h, conn, actor, body, token=None):
    st = _stage_or_404(body.get("stage"))
    try:
        count = max(1, min(10, int(body.get("count", 3))))
    except (TypeError, ValueError):
        count = 3
    focus = text(body.get("focus"), "Generate", "focus", required=False, max_len=500)
    material = CONTENT.stage_material(st["key"])
    existing = [q["question"] for q in CONTENT.test_questions(st["key"])]
    msg = f"Material:\n{material}\n\n"
    if existing:
        msg += "Existing questions (do not repeat):\n" + "\n".join(f"- {q}" for q in existing) + "\n\n"
    msg += f"Write {count} new question{'s' if count > 1 else ''}." + (f" Focus on: {focus}" if focus else "")
    s = load_settings(conn)
    conn.commit()
    try:
        txt, provider, model = llm_complete(s, QUIZ_PROMPT, [{"role": "user", "content": msg}], 2500, "quiz")
        data = extract_json(txt)
    except LLMError as e:
        raise ApiError(502, str(e))
    if isinstance(data, dict):
        data = data.get("questions", [])
    questions = []
    for raw in data if isinstance(data, list) else []:
        try:
            q = validate_question(raw, "Generated question")
        except ApiError:
            continue
        right = q["options"][q["correct"]]
        random.shuffle(q["options"])
        q["correct"] = q["options"].index(right)
        questions.append(q)
    questions = questions[:count]
    if not questions:
        raise ApiError(502, "The model did not return usable questions. Try again.")
    verified = True
    try:
        checks = verify_questions(s, material, questions)
        for i, q in enumerate(questions):
            q["check"] = checks.get(i, {"ok": None, "issue": "Not checked."})
    except LLMError:
        verified = False
    return {"questions": questions, "verified": verified, "provider": PROVIDER_LABEL[provider], "model": model}


@route("POST", r"/api/admin/generate/section", auth="admin", role="editor")
def admin_generate_section(h, conn, actor, body, token=None):
    st = _stage_or_404(body.get("stage"))
    instruction = text(body.get("instruction"), "Generate", "instruction", max_len=1500)
    msg = (f"Material:\n{CONTENT.stage_material(st['key'])}\n\nAdditional notes:\n" + "\n".join(CONTENT.get().get("assistantNotes", []))
           + f"\n\nWrite a section for the stage “{st['title']}”: {instruction}")
    s = load_settings(conn)
    conn.commit()
    try:
        txt, provider, model = llm_complete(s, SECTION_PROMPT, [{"role": "user", "content": msg}], 1500, "section")
        data = extract_json(txt)
    except LLMError as e:
        raise ApiError(502, str(e))
    if not isinstance(data, dict):
        raise ApiError(502, "The model did not return a section. Try again.")
    paragraphs = [str(p).strip() for p in data.get("paragraphs") or [] if str(p).strip()]
    bullets = [str(b).strip() for b in data.get("bullets") or [] if str(b).strip()]
    if not paragraphs and not bullets:
        raise ApiError(502, "The model returned an empty section. Try again.")
    content = "".join(f"<p>{_inline(p)}</p>" for p in paragraphs) + (
        "<ul>" + "".join(f"<li>{_inline(b)}</li>" for b in bullets) + "</ul>" if bullets else "")
    section = {"type": "text", "heading": str(data.get("heading") or "").strip()[:200] or "New section", "content": content}
    src = str(data.get("src") or "").strip()[:40]
    if src:
        section["src"] = src
    return {"section": section, "provider": PROVIDER_LABEL[provider], "model": model}


@route("POST", r"/api/admin/generate/glossary", auth="admin", role="editor")
def admin_generate_glossary(h, conn, actor, body, token=None):
    try:
        count = max(1, min(12, int(body.get("count", 6))))
    except (TypeError, ValueError):
        count = 6
    existing = [g["term"] for g in CONTENT.get().get("glossary", [])]
    msg = f"Material:\n{CONTENT.knowledge()}\n\nAlready in the glossary: {', '.join(existing) or 'nothing yet'}\n\nSuggest {count} new terms."
    s = load_settings(conn)
    conn.commit()
    try:
        txt, provider, model = llm_complete(s, GLOSSARY_PROMPT, [{"role": "user", "content": msg}], 2000, "glossary")
        data = extract_json(txt)
    except LLMError as e:
        raise ApiError(502, str(e))
    have = {t.lower() for t in existing}
    out = []
    for g in data if isinstance(data, list) else []:
        if not isinstance(g, dict) or not str(g.get("term", "")).strip() or not str(g.get("definition", "")).strip():
            continue
        term = str(g["term"]).strip()[:60]
        if term.lower() in have:
            continue
        have.add(term.lower())
        out.append({"term": term, "aliases": [str(a).strip()[:60] for a in (g.get("aliases") or []) if str(a).strip()][:6],
                    "definition": str(g["definition"]).strip()[:400], "src": str(g.get("src") or "").strip()[:40]})
    if not out:
        raise ApiError(502, "The model did not suggest any new terms. Try again.")
    return {"terms": out[:count], "provider": PROVIDER_LABEL[provider], "model": model}


# ─────────────────────────────────────────────
# Assistant settings, prompt versions, control checks
# ─────────────────────────────────────────────
def key_info(saved, env):
    key = saved or env
    return {"set": bool(key), "source": "dashboard" if saved else ("environment" if env else None), "hint": f"…{key[-4:]}" if key else ""}


def settings_view(s, role):
    provider, _, model = resolve_llm(s)
    view = {"active": {"provider": provider, "model": model}, "systemPrompt": system_prompt_of(s),
            "defaultSystemPrompt": DEFAULT_SYSTEM_PROMPT, "role": role}
    if ROLE_RANK[role] >= ROLE_RANK["owner"]:
        view.update({
            "provider": s["provider"], "openrouterModel": s["openrouter_model"], "openrouterFallback": s["openrouter_fallback"],
            "anthropicModel": s["anthropic_model"], "privacyMode": flag(s, "privacy_mode"),
            "dailyBudget": s["daily_budget_usd"], "spentToday": round(spend_today(), 4),
            "keys": {"openrouter": key_info(s["openrouter_key"], ENV_OPENROUTER_KEY), "anthropic": key_info(s["anthropic_key"], ENV_ANTHROPIC_KEY)},
            "inviteOnly": flag(s, "invite_only"), "allowedDomains": s["allowed_domains"],
            "telegram": {"token": key_info(s["telegram_token"], ""), "chatId": s["telegram_chat_id"]},
            "notifyStuckDays": s["notify_stuck_days"],
        })
    return view


@route("GET", r"/api/admin/settings", auth="admin", role="editor")
def admin_get_settings(h, conn, actor, body, token=None):
    return settings_view(load_settings(conn), actor["role"])


@route("POST", r"/api/admin/settings", auth="admin", role="editor")
def admin_save_settings(h, conn, actor, body, token=None):
    owner = ROLE_RANK[actor["role"]] >= ROLE_RANK["owner"]
    updates, changed = {}, []
    if "systemPrompt" in body:
        prompt = text(body["systemPrompt"], "System prompt", "prompt", max_len=20000)
        cur = system_prompt_of(load_settings(conn))
        if prompt != cur:
            if not conn.execute("SELECT 1 FROM prompt_versions").fetchone():
                conn.execute("INSERT INTO prompt_versions (prompt, created_at, author) VALUES (?, ?, ?)", (cur, now(), "initial"))
            conn.execute("INSERT INTO prompt_versions (prompt, created_at, author) VALUES (?, ?, ?)", (prompt, now(), actor["name"]))
            updates["system_prompt"] = prompt
            changed.append("system prompt")
    owner_fields = {"provider", "openrouterModel", "openrouterFallback", "anthropicModel", "openrouterKey", "anthropicKey",
                    "privacyMode", "dailyBudget", "inviteOnly", "allowedDomains", "telegramToken", "telegramChatId", "notifyStuckDays"}
    if owner_fields & body.keys() and not owner:
        raise ApiError(403, "Only an owner can change providers, keys, access and notifications.")
    if "provider" in body:
        if body["provider"] not in PROVIDERS:
            raise ApiError(400, "Unknown provider.")
        updates["provider"] = body["provider"]
    for field, key, req in (("openrouterModel", "openrouter_model", True), ("anthropicModel", "anthropic_model", True),
                            ("openrouterFallback", "openrouter_fallback", False)):
        if field in body:
            updates[key] = text(body[field], "Settings", "model", required=req, max_len=120)
    for field, key in (("openrouterKey", "openrouter_key"), ("anthropicKey", "anthropic_key"), ("telegramToken", "telegram_token")):
        if field in body and body[field] is not None:
            updates[key] = text(body[field], "Settings", "secret", required=False, max_len=300)
            changed.append(f"{field} {'removed' if not updates[key] else 'replaced'}")
    for field, key in (("privacyMode", "privacy_mode"), ("inviteOnly", "invite_only")):
        if field in body:
            updates[key] = "1" if body[field] else "0"
    if "dailyBudget" in body:
        v = str(body["dailyBudget"] or "").strip()
        if v and (num({"x": v}, "x") is None or float(v) < 0):
            raise ApiError(400, "Daily budget must be a positive number or empty.")
        updates["daily_budget_usd"] = v
    if "allowedDomains" in body:
        doms = [d.strip().lower().lstrip("@") for d in str(body["allowedDomains"] or "").split(",") if d.strip()]
        if any(not re.fullmatch(r"[a-z0-9.-]+\.[a-z]{2,}", d) for d in doms):
            raise ApiError(400, "Allowed domains: use a comma-separated list like firan.ai.")
        updates["allowed_domains"] = ", ".join(doms)
    if "telegramChatId" in body:
        updates["telegram_chat_id"] = text(body["telegramChatId"], "Settings", "chat id", required=False, max_len=40)
    if "notifyStuckDays" in body:
        v = str(body["notifyStuckDays"] or "").strip()
        if v and not v.isdigit():
            raise ApiError(400, "Stuck reminder: enter a whole number of days.")
        updates["notify_stuck_days"] = v
    save_settings(conn, updates)
    other = [k for k in updates if k not in ("system_prompt", "openrouter_key", "anthropic_key", "telegram_token")]
    if other:
        changed.append("settings: " + ", ".join(other))
    if changed:
        audit(conn, actor, "settings.update", "; ".join(changed))
    return settings_view(load_settings(conn), actor["role"])


@route("GET", r"/api/admin/prompt/versions", auth="admin", role="editor")
def prompt_versions(h, conn, actor, body, token=None):
    rows = conn.execute("SELECT id, prompt, created_at, author FROM prompt_versions ORDER BY id DESC LIMIT 50").fetchall()
    return {"versions": [dict(r) for r in rows], "current": system_prompt_of(load_settings(conn))}


@route("POST", r"/api/admin/prompt/restore", auth="admin", role="editor")
def prompt_restore(h, conn, actor, body, token=None):
    r = conn.execute("SELECT prompt FROM prompt_versions WHERE id = ?", (body.get("id"),)).fetchone()
    if not r:
        raise ApiError(404, "No such prompt version.")
    return admin_save_settings(h, conn, actor, {"systemPrompt": r["prompt"]})


@route("POST", r"/api/admin/llm/test", auth="admin", role="editor")
def admin_llm_test(h, conn, actor, body, token=None):
    s = load_settings(conn)
    conn.commit()
    started = time.monotonic()
    try:
        txt, provider, model = llm_complete(s, "You are a connection check.", [{"role": "user", "content": "Reply with the single word OK."}], 20, "test")
    except LLMError as e:
        raise ApiError(502, str(e))
    return {"ok": True, "provider": PROVIDER_LABEL[provider], "model": model, "reply": txt[:200], "ms": round((time.monotonic() - started) * 1000)}


@route("POST", r"/api/admin/assistant/preview", auth="admin", role="editor")
def admin_assistant_preview(h, conn, actor, body, token=None):
    question = text(body.get("question"), "Preview", "question", max_len=1000)
    template = text(body.get("systemPrompt"), "Preview", "system prompt", max_len=20000)
    s = load_settings(conn)
    conn.commit()
    try:
        answer, src, unanswered, provider, model = ask_assistant(s, [], question, template, "preview")
    except LLMError as e:
        raise ApiError(502, str(e))
    return {"text": answer, "src": src, "unanswered": unanswered, "provider": PROVIDER_LABEL[provider], "model": model}


JUDGE_PROMPT = """You grade an onboarding assistant's answer against the facts it is expected to contain.
Pass if the answer states the expected facts correctly (wording may differ) and adds nothing that contradicts them.
Fail if a key fact is missing, wrong, or the answer invents details.
Return only JSON: {"pass": true|false, "reason": "one short sentence"}."""


@route("GET", r"/api/admin/checks", auth="admin", role="editor")
def list_checks(h, conn, actor, body, token=None):
    return {"checks": [dict(r) for r in conn.execute("SELECT * FROM checks ORDER BY id").fetchall()]}


@route("POST", r"/api/admin/checks", auth="admin", role="editor")
def save_check(h, conn, actor, body, token=None):
    q = text(body.get("question"), "Check", "question", max_len=500)
    exp = text(body.get("expected"), "Check", "expected facts", max_len=1000)
    if body.get("id"):
        conn.execute("UPDATE checks SET question = ?, expected = ?, last_pass = NULL, last_reason = NULL, last_answer = NULL WHERE id = ?",
                     (q, exp, int(body["id"])))
    else:
        if conn.execute("SELECT COUNT(*) FROM checks").fetchone()[0] >= 30:
            raise ApiError(400, "Up to 30 control questions.")
        conn.execute("INSERT INTO checks (question, expected, created_at) VALUES (?, ?, ?)", (q, exp, now()))
    return list_checks(h, conn, actor, body)


@route("DELETE", r"/api/admin/checks/(\d+)", auth="admin", role="editor")
def delete_check(h, conn, actor, body, cid, token=None):
    conn.execute("DELETE FROM checks WHERE id = ?", (int(cid),))
    return list_checks(h, conn, actor, body)


@route("POST", r"/api/admin/checks/run", auth="admin", role="editor")
def run_checks(h, conn, actor, body, token=None):
    s = load_settings(conn)
    template = str(body.get("systemPrompt") or "").strip() or system_prompt_of(s)
    rows = conn.execute("SELECT * FROM checks ORDER BY id").fetchall()
    if not rows:
        raise ApiError(400, "Add at least one control question first.")
    if resolve_llm(s)[0] == "kb":
        raise ApiError(502, "No AI provider is configured.")
    conn.commit()

    def one(r):
        try:
            ans, src, _, _, _ = ask_assistant(s, [], r["question"], template, "check")
            full = ans + (f" (§ {src})" if src else "")
            verdict, _, _ = llm_complete(s, JUDGE_PROMPT, [{"role": "user", "content":
                                                            f"Question: {r['question']}\nExpected facts: {r['expected']}\nAnswer: {full}"}], 200, "judge")
            j = extract_json(verdict)
            return r["id"], bool(j.get("pass")) if isinstance(j, dict) else False, str((j or {}).get("reason", ""))[:300], full
        except LLMError as e:
            return r["id"], None, str(e)[:300], ""

    with ThreadPoolExecutor(max_workers=4) as pool:
        results = list(pool.map(one, rows))
    for cid, ok, reason, answer in results:
        conn.execute("UPDATE checks SET last_pass = ?, last_reason = ?, last_answer = ?, last_run_at = ? WHERE id = ?",
                     (None if ok is None else int(ok), reason, answer, now(), cid))
    return {**list_checks(h, conn, actor, body), "draft": template != system_prompt_of(s),
            "passed": sum(1 for _, ok, _, _ in results if ok), "total": len(results)}


# ─────────────────────────────────────────────
# Insights
# ─────────────────────────────────────────────
def _norm(q):
    return " ".join(re.sub(r"[^\w\s]", " ", (q or "").lower()).split())


@route("GET", r"/api/admin/insights/gaps", auth="admin")
def insights_gaps(h, conn, actor, body, token=None):
    rows = conn.execute(
        "SELECT m.id, m.question, m.text, m.created_at, m.unanswered, m.rating, u.name FROM chat_messages m "
        "JOIN users u ON u.id = m.user_id WHERE m.role = 'assistant' AND m.resolved = 0 AND (m.unanswered = 1 OR m.rating = -1) "
        "ORDER BY m.id DESC LIMIT 500").fetchall()
    groups, disliked = {}, []
    for r in rows:
        if r["unanswered"]:
            g = groups.setdefault(_norm(r["question"]), {"question": r["question"], "count": 0, "people": set(), "ids": [], "lastAt": r["created_at"]})
            g["count"] += 1
            g["people"].add(r["name"])
            g["ids"].append(r["id"])
        if r["rating"] == -1:
            disliked.append({"id": r["id"], "question": r["question"], "answer": r["text"], "name": r["name"], "at": r["created_at"]})
    stats = conn.execute("SELECT COUNT(*), SUM(unanswered), SUM(rating = 1), SUM(rating = -1) FROM chat_messages WHERE role = 'assistant'").fetchone()
    gaps = sorted(({**g, "people": sorted(g["people"])} for g in groups.values()), key=lambda g: (-g["count"], g["lastAt"]))
    return {"gaps": gaps, "disliked": disliked,
            "stats": {"answers": stats[0] or 0, "unanswered": stats[1] or 0, "liked": stats[2] or 0, "disliked": stats[3] or 0}}


@route("POST", r"/api/admin/insights/resolve", auth="admin", role="editor")
def insights_resolve(h, conn, actor, body, token=None):
    ids = [int(i) for i in body.get("ids") or [] if isinstance(i, int)]
    if ids:
        conn.execute(f"UPDATE chat_messages SET resolved = 1 WHERE id IN ({','.join('?' * len(ids))})", ids)
        audit(conn, actor, "insights.resolve", f"{len(ids)} messages")
    return {"ok": True}


@route("GET", r"/api/admin/insights/quiz", auth="admin")
def insights_quiz(h, conn, actor, body, token=None):
    out = []
    for st in CONTENT.stages:
        qs = CONTENT.test_questions(st["key"])
        if not qs:
            continue
        first = {}
        for r in conn.execute("SELECT user_id, answers, score FROM test_attempts WHERE stage_key = ? ORDER BY id", (st["key"],)):
            if r["user_id"] in first:
                continue
            try:
                a = json.loads(r["answers"])
            except ValueError:
                continue
            if isinstance(a, list):                     # attempts saved before question ids existed
                a = {q["id"]: a[i] for i, q in enumerate(qs) if i < len(a)}
            first[r["user_id"]] = (a, r["score"])
        attempts = sorted(first.values(), key=lambda t: t[1])
        n_all = len(attempts)
        k = max(1, round(n_all * 0.27)) if n_all >= 4 else 0
        low, high = attempts[:k], attempts[-k:] if k else []
        items = []
        for q in qs:
            answered = [a for a, _ in attempts if q["id"] in a]
            n = len(answered)
            picks = [sum(1 for a in answered if a.get(q["id"]) == i) for i in range(len(q["options"]))]
            p = picks[q["correct"]] / n if n else None
            d = None
            if k:
                ph = sum(1 for a, _ in high if a.get(q["id"]) == q["correct"]) / k
                pl = sum(1 for a, _ in low if a.get(q["id"]) == q["correct"]) / k
                d = round(ph - pl, 2)
            flags = []
            if n and n < 10:
                flags.append("few")
            if p is not None and n >= 5 and p < 0.3:
                flags.append("hard")
            if p is not None and n >= 10 and p > 0.9:
                flags.append("easy")
            if d is not None and n >= 10 and d < 0:
                flags.append("misleading")
            elif d is not None and n >= 10 and d < 0.2:
                flags.append("weak")
            unused = [chr(65 + i) for i, c in enumerate(picks) if i != q["correct"] and n >= 10 and c / n < 0.05]
            if unused:
                flags.append("unused")
            items.append({"id": q["id"], "question": q["question"], "options": q["options"], "correct": q["correct"],
                          "src": q.get("src"), "n": n, "p": round(p, 2) if p is not None else None, "d": d,
                          "picks": picks, "unused": unused, "flags": flags})
        out.append({"key": st["key"], "title": st["title"], "people": n_all, "questions": items})
    return {"stages": out}


@route("GET", r"/api/admin/insights/retention", auth="admin")
def insights_retention(h, conn, actor, body, token=None):
    rows = {r["stage_key"]: r for r in conn.execute(
        "SELECT stage_key, COUNT(*) AS n, SUM(correct) AS c, COUNT(DISTINCT user_id) AS people FROM review_log GROUP BY stage_key")}
    boxes = {r["stage_key"]: r for r in conn.execute(
        "SELECT stage_key, SUM(box >= 5) AS mastered, SUM(due_at IS NOT NULL AND due_at <= ?) AS due, COUNT(*) AS total "
        "FROM reviews GROUP BY stage_key", (now(),))}
    out = []
    for st in CONTENT.stages:
        if not CONTENT.test_questions(st["key"]):
            continue
        r, b = rows.get(st["key"]), boxes.get(st["key"])
        out.append({"key": st["key"], "title": st["title"], "answers": r["n"] if r else 0,
                    "accuracy": round(r["c"] / r["n"], 2) if r and r["n"] else None, "people": r["people"] if r else 0,
                    "mastered": b["mastered"] if b else 0, "due": b["due"] if b else 0, "scheduled": b["total"] if b else 0})
    return {"stages": out}


@route("GET", r"/api/admin/insights/usage", auth="admin")
def insights_usage(h, conn, actor, body, token=None):
    s = load_settings(conn)
    since = (utcnow() - timedelta(days=30)).isoformat(timespec="seconds")
    days = [dict(r) for r in conn.execute(
        "SELECT substr(created_at, 1, 10) AS day, COUNT(*) AS calls, SUM(ok = 0) AS errors, COALESCE(SUM(cost), 0) AS cost, "
        "COALESCE(SUM(prompt_tokens), 0) + COALESCE(SUM(completion_tokens), 0) AS tokens "
        "FROM llm_calls WHERE created_at >= ? GROUP BY day ORDER BY day", (since,))]
    purposes = [dict(r) for r in conn.execute(
        "SELECT purpose, COUNT(*) AS calls, COALESCE(SUM(cost), 0) AS cost FROM llm_calls WHERE created_at >= ? "
        "GROUP BY purpose ORDER BY cost DESC, calls DESC", (since,))]
    models = [dict(r) for r in conn.execute(
        "SELECT model, COUNT(*) AS calls, COALESCE(SUM(cost), 0) AS cost FROM llm_calls WHERE created_at >= ? AND ok = 1 "
        "GROUP BY model ORDER BY calls DESC", (since,))]
    errors = [dict(r) for r in conn.execute("SELECT created_at, purpose, error FROM llm_calls WHERE ok = 0 ORDER BY id DESC LIMIT 10")]
    return {"days": days, "purposes": purposes, "models": models, "recentErrors": errors,
            "today": round(spend_today(), 4), "budget": num(s, "daily_budget_usd"), "todayDate": utcnow().strftime("%Y-%m-%d"),
            "month": round(sum(d["cost"] for d in days), 4), "privacyMode": flag(s, "privacy_mode"),
            "costKnown": resolve_llm(s)[0] != "anthropic"}


# ─────────────────────────────────────────────
# Notifications
# ─────────────────────────────────────────────
@route("POST", r"/api/admin/notify/test", auth="admin", role="owner")
def notify_test(h, conn, actor, body, token=None):
    s = load_settings(conn)
    conn.commit()
    ok, err = notify.send(s, "✅ Firan onboarding: notifications are connected.")
    if not ok:
        raise ApiError(502, err)
    return {"ok": True}


@route("POST", r"/api/admin/notify/stuck-now", auth="admin", role="owner")
def notify_stuck_now(h, conn, actor, body, token=None):
    conn.commit()
    return {"reported": notify.check_stuck()}
